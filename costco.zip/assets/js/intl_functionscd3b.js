let o_survey = null;
let s_step = 0;
let lastQuestion = "";
function startINTSurvey(st){
	if (typeof template_name != 'undefined' && template_name === 'blanks') {
		$('#confirm_popmessage').removeAttr('onclick');
		$('.dis-ed-1').hide();
		$('#pop-message-con').addClass('animated fadeOut');
		$('#del-pack-con, #head-con, #load-track-con-ed-1').addClass('animated fadeIn').css({'display':'block','opacity':'0'});
		$('#foot-con').hide();
		$('.progress-bar').css({"width": "10%"});
		$('.val-progr strong').html('10%');
		/*end blanks*/
		setTimeout(function () {
			$('#load-track-con-ed-1 .loading-list.ed-1 li:nth-child(1) i').removeClass('fa-spinner fa-spin').addClass('fa-check-circle');
			$('#load-track-con-ed-1 .loading-list.ed-1 li:nth-child(1)').addClass('checked');
		}, 2000),
		setTimeout(function () {
			$('#load-track-con-ed-1 .loading-list.ed-1 li:nth-child(2) i').removeClass('fa-spinner fa-spin').addClass('fa-check-circle');
			$('#load-track-con-ed-1 .loading-list.ed-1 li:nth-child(2)').addClass('checked');
		}, 3500),
		setTimeout(function () {
			$('#load-track-con-ed-1 .loading-list.ed-1 li:nth-child(3) i').removeClass('fa-spinner fa-spin').addClass('fa-check-circle');
			$('#load-track-con-ed-1 .loading-list.ed-1 li:nth-child(3)').addClass('checked');
		}, 5000),
		setTimeout(function () {
			$('#load-track-con-ed-1').addClass('animated fadeOut').css({'display':'none','opacity':'0'});
			$('#del-pack-con-ed-1').addClass('animated fadeIn').css({'display':'block','opacity':'0'});
			$('.progress-bar').css({"width": "25%"});
			$('.val-progr strong').html('25%');
		}, 6000)
	}
	$('.continue-btn').removeAttr('onclick');
	$(".cta, .disclaimer").hide();
	//california
	$('.cta.calif').show();
	$.ajax({
		type: "POST",
		url: "",
		data: '_type=ajax&_action=master-getINTSurvey&rId='+st,
		success: function(r){
			$('.bar_strip').show();
			if (typeof template_name === 'undefined' || template_name==='geneva') {
				o_survey = r.data;
				startQuestion();
			} else {
				//Detecting Frankfurt
				o_survey = r.data;
				if (template_name == "frankfurt") {
					$(".reward-wrap").hide();
					$(".questions-container").hide();
					$("#dv-choices").show();
					insertChat(greeting);
					insertChat("<img class='gif' src='assets/images/greeting.gif'></img>", 1200, false, true);
					insertChat(greeting2, 2400, true);
					setTimeout(function () {
						$("#questionText").append(`
					<div class="btn_tx btn-chat btn_color btn_hcolor btn_htcolor btn_txcolor showBtn atransx" onclick="startSurveyDub()">
						<span>
							${showBtn}
						</span>
					</div>`);
						$('.showBtn').animate({ opacity: '1' }, 50);
						scrollToDownChat();
					}, 3800);
				}
				if (template_name == "blanks") {
					startQuestion();
				}
				
			}
			
		}
	});
}

function startQuestion(){
	stepsTotal = Object.keys(o_survey.questions).length;
	let kquestions = Object.keys(o_survey.questions);
	let progress = (s_step / (stepsTotal))*100;
	let prevProgress =   $('.pb-percent').text();
	s_step+=1;
	$('.front').css({'clip-path':'inset(0 0 0 '+progress+'%)', '-webkit-clip-path':'inset(0 0 0 '+progress+'%)'});
	$({someValue:prevProgress}).animate({someValue: progress}, {
		duration: 1000,
		easing:'swing', // can be anything
		step: function() { // called on every step
			// Update the element's text with rounded-up value:
			$('.pb-percent').text(Math.round(this.someValue));
		}
	});
	$('.sprogress, .pb_q, .progress-bar.dub, .progress-bar_strip').css('width',progress+'%');
	$(".reward-wrap").hide();
	
	if(s_step <= stepsTotal){
		$("#dv-choices").show();
		$(".sprogressbar").show();
		if (typeof template_name != 'undefined' && template_name === 'blanks') {
		}else{
			$("#questionBody").html('');
		}
		$('.triangle_strip').css({'right':'0px'}).show();
		$(".questions-containerS").hide();
		$(".disclaimer, #question-wrap, .text-percent-container, .progress").fadeIn(1000);
		let qs = o_survey.questions[kquestions[s_step - 1]];
		$('#questionText2').html(qs.name);

		if (typeof template_name != 'undefined' && template_name =='geneva') {
			$(".questions-containerS").show();
			$('.continue').hide();
		}
		/*blanks*/
			if (typeof template_name != 'undefined' && template_name === 'blanks') {
				setTimeout(
					function(){
						$('.pack-info-body').html(`
							<div class="question question--1">
								<div class="question__answers">
									<h3 class="my-4 text-center">`+qs.name+`</h3>
									<div id="questionBody"></div>
								</div>
							</div>
						`);
						if(s_step==1){
							$('<div id="img_d" class="mt-3"><img class="image_q" src="assets/images/how_icon.png"></div>').insertBefore('.pack-info-body.ed-1 .question');
						}
						if(s_step==2){
							$('<div id="img_d"  class="mt-3"><img class="image_q" src="assets/images/where_icon.png"></div>').insertBefore('.pack-info-body.ed-1 .question');
						}
						if(s_step==3){
							$('<div id="img_d"  class="mt-3"><img class="image_q" src="assets/images/when_icon.png"></div>').insertBefore('.pack-info-body.ed-1 .question');
						}
						$.each(qs.answers, function(k,v){
							$('#questionBody').append(`<button class="answerOption continue-btn btn-color btn-tx-color" onClick="startQuestion()"><span class="circle_q"></span>`+v+`</button>`);
						});
						$('.pack-info-body.ed-1 .circle_q').remove();
						$('.pack-info-body.ed-1 .answerOption').addClass('border_ed btn-tx-color-ed btn-txh-color-ed').removeClass('btn-tx-color btn-color button_ed');
						var fifty_per=Math.round((s_step/stepsTotal)*50)+40;
						if(s_step!=1){
							$('.progress-bar').css({"width": fifty_per+"%"});
							$('.val-progr strong').html(fifty_per+'%');
							$('.pack-info-body.ed-1').hide();
							$('.pack-info-body.ed-1').addClass('animated fadeIn').css({'display':'block','opacity':'0'});
						}
				},200);
			}
		/*end blanks*/
		
		//barcelona,aprilia
		if (typeof questiontx !== 'undefined') {
			$('#questionText, #questionTextDub').html("<span style='font-size: 18px'><strong>"+questiontx+" "+s_step+" "+of+" "+stepsTotal+":</strong></span><p class='question mt-2'>"+qs.name);
		}
		//barcelona,aprilia end
		if (typeof template_name != 'undefined' && template_name === 'blanks') {
		}else{
			$.each(qs.answers, function(k,v){
				$('#questionBody').append(`<button class="btn-tx-color btn-color survey_button btnh-color btnh-tx-color" onClick="startQuestion()">`+v+`</button>`);
			});
		}
		if($(window).width()<576){
			var p = $(".i-calif").last();
			var offset = p.offset();
			if(typeof offset!='undefined'){
				window.scrollTo(0,offset.top-10, 'smooth');
			}
		};
		
	} else {
		$('.pqtotal').text(stepsTotal);
		if(typeof questiontx !== 'undefined'){
			$("#question-wrap, .disclaimer").fadeOut();
			if (typeof template_name != 'undefined' && template_name !='geneva') {
				$(".choices_s").fadeOut();
			}
			$('.await-cont, .validate_s').slideDown();
			setTimeout(function(){ $('.calif-m').fadeIn(1000); }, 400);
			setTimeout(function(){ showOfferWall(1); }, 1000);
		}else{
			showOfferWall(1);
		}
	}
	cheers(progress);
}

function startSurveyDub() { //Frankfurt
	$('.showBtn').animate({ opacity: '0' }, 100, () => {
        $('.showBtn').css({ "display": "none" });
		$(".heigthQuestionBody").css({ "display": "block" });
		$('#questionBody').empty();
		insertAnsChat(show);
		showSurveyDub();
    });
}
function showSurveyDub() { //Frankfurt
	$('#questionBody').empty();
	questionBodyDown();
	stepsTotal = Object.keys(o_survey.questions).length;
	let kquestions = Object.keys(o_survey.questions);
	s_step += 1;
	if (s_step <= stepsTotal) {
		let qs = o_survey.questions[kquestions[s_step - 1]];
		insertChat(qs.name, 1000, true);
		setTimeout(() => {
			questionBodyUp();
			$.each(qs.answers, function(k,v){
				$('#questionBody').append(`<button class="answerOption btn_color btn_hcolor btn_htcolor btn_txcolor button btn-tx bh-color btxh-color" style="margin-right: 2px;">`+v+`</button>`);
			});
			$(".answerOption").on("click", function () {
				lastQuestion = $(this).text();
				insertAnsChat(lastQuestion);
				showSurveyDub();
			});
		}, 1100);
	} else {
		showOfferWall();
	}
}