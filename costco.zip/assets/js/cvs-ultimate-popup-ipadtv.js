/**
 * CVS SURVEY - MAXIMUM CONVERSION POPUP
 * Every pixel optimized for psychological impact
 * Compact design with layered persuasion triggers
 */

(function() {
    'use strict';
    
    // ================== CONFIGURATION ==================
    const CONFIG = {
        timing: {
            firstShow: 10000,
            interval: 22000,
            displayDuration: 6500,
        },
        limits: {
            maxRecentCities: 20,
            sessionLimit: 10
        }
    };

    // ================== DATA ARRAYS ==================
    
    const CITIES = [
        "New York, NY", "Los Angeles, CA", "Chicago, IL", "Houston, TX", "Phoenix, AZ",
        "Philadelphia, PA", "San Antonio, TX", "San Diego, CA", "Dallas, TX", "Austin, TX",
        "Jacksonville, FL", "Fort Worth, TX", "Columbus, OH", "Charlotte, NC", "San Francisco, CA",
        "Indianapolis, IN", "Seattle, WA", "Denver, CO", "Washington, DC", "Boston, MA",
        "Nashville, TN", "Detroit, MI", "Portland, OR", "Las Vegas, NV", "Memphis, TN",
        "Louisville, KY", "Baltimore, MD", "Milwaukee, WI", "Albuquerque, NM", "Tucson, AZ",
        "Fresno, CA", "Atlanta, GA", "Kansas City, MO", "Colorado Springs, CO", "Raleigh, NC",
        "Miami, FL", "Long Beach, CA", "Virginia Beach, VA", "Oakland, CA", "Minneapolis, MN",
        "Tampa, FL", "Tulsa, OK", "Arlington, TX", "New Orleans, LA", "Cleveland, OH",
        "Bakersfield, CA", "Wichita, KS", "Aurora, CO", "Anaheim, CA", "Honolulu, HI",
        "Santa Ana, CA", "Riverside, CA", "Corpus Christi, TX", "Lexington, KY", "Henderson, NV",
        "Stockton, CA", "Saint Paul, MN", "Cincinnati, OH", "St. Louis, MO", "Pittsburgh, PA",
        "Greensboro, NC", "Anchorage, AK", "Plano, TX", "Lincoln, NE", "Orlando, FL",
        "Irvine, CA", "Newark, NJ", "Durham, NC", "Chula Vista, CA", "Toledo, OH",
        "Fort Wayne, IN", "St. Petersburg, FL", "Laredo, TX", "Jersey City, NJ", "Chandler, AZ",
        "Madison, WI", "Lubbock, TX", "Scottsdale, AZ", "Reno, NV", "Buffalo, NY",
        "Gilbert, AZ", "Glendale, AZ", "North Las Vegas, NV", "Winston-Salem, NC", "Chesapeake, VA",
        "Norfolk, VA", "Fremont, CA", "Garland, TX", "Irving, TX", "Richmond, VA",
        "Boise, ID", "Spokane, WA", "Baton Rouge, LA", "Tacoma, WA", "San Bernardino, CA",
        "Modesto, CA", "Fontana, CA", "Des Moines, IA", "Moreno Valley, CA", "Santa Clarita, CA"
    ];

    const NAMES = [
        "James R.", "Mary S.", "Michael T.", "Jennifer P.", "Robert W.", "Linda M.", "David C.",
        "Barbara B.", "William H.", "Elizabeth G.", "Richard L.", "Susan K.", "Joseph F.",
        "Jessica N.", "Thomas E.", "Sarah V.", "Christopher A.", "Karen Z.", "Charles Q.",
        "Nancy Y.", "Daniel X.", "Lisa U.", "Matthew I.", "Betty O.", "Anthony R.", "Margaret C.",
        "Mark M.", "Sandra B.", "Donald L.", "Ashley K.", "Steven J.", "Kimberly F.", "Andrew H.",
        "Emily D.", "Paul G.", "Donna S.", "Joshua T.", "Michelle P.", "Kenneth M.", "Carol B.",
        "Kevin L.", "Amanda K.", "Brian J.", "Melissa F.", "George H.", "Deborah D.", "Timothy R.",
        "Stephanie S.", "Ronald P.", "Rebecca M.", "Edward B.", "Sharon L.", "Jason K.", "Laura J.",
        "Jeffrey F.", "Cynthia H.", "Ryan D.", "Kathleen S.", "Jacob T.", "Amy P.", "Gary M.",
        "Angela B.", "Nicholas L.", "Shirley K.", "Eric J.", "Brenda F.", "Jonathan H.", "Emma R.",
        "Stephen D.", "Anna S.", "Larry P.", "Pamela M.", "Justin B.", "Nicole K.", "Scott L.",
        "Samantha J.", "Brandon F.", "Katherine H.", "Benjamin D.", "Christine R.", "Samuel S.",
        "Debra P.", "Raymond M.", "Rachel B.", "Gregory L.", "Carolyn K.", "Alexander J.", "Janet F.",
        "Patrick H.", "Catherine D.", "Frank S.", "Maria P.", "Jack M.", "Heather B.", "Dennis L.",
        "Diane K.", "Jerry J.", "Virginia F.", "Tyler H.", "Julie D.", "Aaron S.", "Joyce P."
    ];

    const PRODUCTS = [
        {
            name: "claimed an Apple iPad Pro",
            image: "https://i.postimg.cc/PrKxxtLw/ipadpro-resized.jpg",
            weight: 40,
            value: "$799 value",
            stock: "3 left"
        },
        {
            name: "claimed a Samsung 65\" Neo QLED 4K TV",
            image: "https://i.postimg.cc/76j9CbxY/samsung-4k-resized.jpg",
            weight: 35,
            value: "$2,099 value",
            stock: "2 left"
        },
        {
            name: "claimed a Dell Inspiron 16\" Laptop",
            image: "https://i.postimg.cc/SxH7mp27/dell-inspiron-16.png",
            weight: 25,
            value: "$699 value",
            stock: "0 left"
        }
    ];

    // ================== STATE MANAGEMENT ==================
    
    const state = {
        recentCities: [],
        popupCount: 0,
        isVisible: false
    };

    // ================== UTILITY FUNCTIONS ==================
    
    function getUniqueRandom(array, recentArray, maxRecent) {
        let attempts = 0;
        let index;
        
        do {
            index = Math.floor(Math.random() * array.length);
            attempts++;
        } while (recentArray.includes(index) && attempts < 50 && recentArray.length < array.length);
        
        if (recentArray.length >= maxRecent) {
            recentArray.shift();
        }
        recentArray.push(index);
        
        return index;
    }

    function getWeightedProduct() {
        const totalWeight = PRODUCTS.reduce((sum, product) => sum + product.weight, 0);
        let random = Math.random() * totalWeight;
        
        for (let i = 0; i < PRODUCTS.length; i++) {
            random -= PRODUCTS[i].weight;
            if (random <= 0) {
                return i;
            }
        }
        return 0;
    }

    function getTimeAgo() {
        const rand = Math.random();
        if (rand < 0.5) {
            const minutes = Math.floor(Math.random() * 45) + 1;
            return `${minutes}m ago`;
        } else if (rand < 0.85) {
            const minutes = Math.floor(Math.random() * 30) + 45;
            return `${minutes}m ago`;
        } else {
            const hours = Math.floor(Math.random() * 3) + 1;
            return `${hours}h ago`;
        }
    }

    // ================== DOM CREATION ==================
    
    function createPopupHTML() {
        return `
            <div class="cvs-social-proof">
                <div class="cvs-notification">
                    <div class="cvs-close">×</div>
                    <div class="cvs-status-bar">
                        <span class="cvs-pulse"></span>
                        <span class="cvs-status-text">LIVE</span>
                        <span class="cvs-verified-badge">
                            <i class="fa fa-check-circle"></i>
                            <img src="master/img/cvspopup.png" alt="CVS" class="cvs-logo-img">
                            Verified
                        </span>
                    </div>
                    <div class="cvs-content">
                        <div class="cvs-image-wrapper">
                            <img id="cvs-product-img" src="" alt="Product">
                            <div class="cvs-stock-badge" id="cvs-stock"></div>
                        </div>
                        <div class="cvs-details">
                            <div class="cvs-user-info">
                                <span class="cvs-name" id="cvs-customer-name"></span>
                                <span class="cvs-location">
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
                                        <path d="M5 0C3.07 0 1.5 1.57 1.5 3.5c0 2.19 3.5 6.5 3.5 6.5s3.5-4.31 3.5-6.5C8.5 1.57 6.93 0 5 0zm0 4.75c-.69 0-1.25-.56-1.25-1.25S4.31 2.25 5 2.25s1.25.56 1.25 1.25S5.69 4.75 5 4.75z"/>
                                    </svg>
                                    <span id="cvs-city"></span>
                                </span>
                            </div>
                            <div class="cvs-action" id="cvs-product-name"></div>
                            <div class="cvs-meta">
                                <span class="cvs-value" id="cvs-value"></span>
                                <span class="cvs-separator">•</span>
                                <span class="cvs-time" id="cvs-time"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    function createStyles() {
        return `
            <style id="cvs-popup-styles">
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
                
                .cvs-social-proof {
                    position: fixed;
                    bottom: 20px;
                    left: 20px;
                    z-index: 999999;
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                    display: none;
                }

                .cvs-notification {
                    width: 380px;
                    max-width: calc(100vw - 40px);
                    border-radius: 12px;
                    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.08);
                    background: #ffffff;
                    position: relative;
                    animation: cvs-slide-in 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                    overflow: hidden;
                    border: 1px solid rgba(0, 0, 0, 0.08);
                }

                @keyframes cvs-slide-in {
                    0% {
                        transform: translateX(-400px);
                        opacity: 0;
                    }
                    100% {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }

                @keyframes cvs-slide-out {
                    0% {
                        transform: translateX(0) scale(1);
                        opacity: 1;
                    }
                    100% {
                        transform: translateX(-400px) scale(0.95);
                        opacity: 0;
                    }
                }

                .cvs-social-proof.cvs-hiding .cvs-notification {
                    animation: cvs-slide-out 0.3s cubic-bezier(0.55, 0.085, 0.68, 0.53) forwards;
                }

                .cvs-status-bar {
                    background: linear-gradient(135deg, #CC0000 0%, #990000 100%);
                    padding: 7px 16px;
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }

                .cvs-pulse {
                    width: 8px;
                    height: 8px;
                    background: #fff;
                    border-radius: 50%;
                    animation: cvs-pulse-animation 2s ease-in-out infinite;
                    box-shadow: 0 0 0 0 rgba(255, 255, 255, 1);
                }

                @keyframes cvs-pulse-animation {
                    0%, 100% {
                        transform: scale(1);
                        opacity: 1;
                    }
                    50% {
                        transform: scale(1.3);
                        opacity: 0.7;
                    }
                }

                .cvs-status-text {
                    color: #fff;
                    font-size: 13px;
                    font-weight: 700;
                    letter-spacing: 0.5px;
                    text-transform: uppercase;
                    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
                    line-height: 1;
                }

                .cvs-verified-badge {
                    margin-left: auto;
                    background: rgba(255, 255, 255, 0.15);
                    padding: 4px 10px;
                    border-radius: 20px;
                    font-size: 13px;
                    color: #fff;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 5px;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                    line-height: 1;
                }

                .cvs-verified-badge i {
                    font-size: 13px;
                    line-height: 1;
                }

                .cvs-logo-img {
                    height: 11px;
                    width: auto;
                    display: block;
                    filter: brightness(0) invert(1);
                    object-fit: contain;
                }

                .cvs-content {
                    padding: 14px;
                    display: flex;
                    gap: 12px;
                }

                .cvs-image-wrapper {
                    position: relative;
                    flex-shrink: 0;
                    width: 70px;
                    height: 70px;
                }

                .cvs-image-wrapper img {
                    width: 70px;
                    height: 70px;
                    border-radius: 10px;
                    object-fit: cover;
                    border: 1px solid rgba(0, 0, 0, 0.06);
                }

                .cvs-stock-badge {
                    position: absolute;
                    bottom: -6px;
                    right: -6px;
                    background: #CC0000;
                    color: white;
                    font-size: 10px;
                    font-weight: 700;
                    padding: 4px 8px;
                    border-radius: 12px;
                    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
                    white-space: nowrap;
                    animation: cvs-badge-pop 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) 0.3s both;
                    border: 2px solid #ffffff;
                }

                @keyframes cvs-badge-pop {
                    0% {
                        transform: scale(0);
                        opacity: 0;
                    }
                    100% {
                        transform: scale(1);
                        opacity: 1;
                    }
                }

                .cvs-details {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    gap: 6px;
                }

                .cvs-user-info {
                    display: flex;
                    flex-direction: column;
                    gap: 3px;
                }

                .cvs-name {
                    color: #1a1a1a;
                    font-size: 16px;
                    font-weight: 600;
                    letter-spacing: -0.01em;
                }

                .cvs-location {
                    color: #666;
                    font-size: 14px;
                    display: flex;
                    align-items: center;
                    gap: 5px;
                    font-weight: 400;
                }

                .cvs-location svg {
                    flex-shrink: 0;
                    opacity: 0.6;
                }

                .cvs-action {
                    color: #2d2d2d;
                    font-size: 14px;
                    line-height: 1.2;
                    font-weight: 500;
                }

                .cvs-meta {
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    font-size: 13px;
                    color: #888;
                    margin-top: 3px;
                }

                .cvs-value {
                    color: #CC0000;
                    font-weight: 700;
                    font-size: 14px;
                }

                .cvs-separator {
                    opacity: 0.4;
                    font-weight: 300;
                }

                .cvs-time {
                    color: #999;
                    font-weight: 400;
                }

                .cvs-close {
                    position: absolute;
                    top: 33px;
                    right: 12px;
                    width: 24px;
                    height: 24px;
                    border-radius: 50%;
                    background: rgba(0, 0, 0, 0.04);
                    color: #666;
                    font-size: 18px;
                    line-height: 24px;
                    text-align: center;
                    cursor: pointer;
                    transition: all 0.2s ease;
                    opacity: 0;
                    z-index: 10;
                    font-weight: 300;
                }

                .cvs-notification:hover .cvs-close {
                    opacity: 1;
                }

                .cvs-close:hover {
                    background: rgba(204, 0, 0, 0.08);
                    color: #CC0000;
                    transform: scale(1.1);
                }

                /* Mobile Responsive */
                @media (max-width: 480px) {
                    .cvs-social-proof {
                        left: 10px;
                        right: 10px;
                        bottom: 10px;
                    }

                    .cvs-notification {
                        width: 100%;
                    }

                    .cvs-status-bar {
                        padding: 6px 14px;
                    }

                    .cvs-content {
                        padding: 14px;
                    }

                    .cvs-image-wrapper img {
                        width: 60px;
                        height: 60px;
                    }

                    .cvs-name {
                        font-size: 14px;
                    }

                    .cvs-location {
                        font-size: 12px;
                    }

                    .cvs-action {
                        font-size: 13px;
                    }

                    .cvs-meta {
                        font-size: 11px;
                    }

                    .cvs-value {
                        font-size: 12px;
                    }
                }
            </style>
        `;
    }

    // ================== POPUP LOGIC ==================
    
    function init() {
        if (document.getElementById('cvs-popup-styles')) {
            return;
        }

        document.head.insertAdjacentHTML('beforeend', createStyles());
        document.body.insertAdjacentHTML('beforeend', createPopupHTML());

        const popup = document.querySelector('.cvs-social-proof');
        popup.querySelector('.cvs-close').addEventListener('click', hidePopup);

        setTimeout(showPopup, CONFIG.timing.firstShow);
        setInterval(attemptShowPopup, CONFIG.timing.interval);
    }

    function attemptShowPopup() {
        if (state.popupCount < CONFIG.limits.sessionLimit && !state.isVisible) {
            showPopup();
        }
    }

    function showPopup() {
        const popup = document.querySelector('.cvs-social-proof');
        if (!popup) return;

        const cityIndex = getUniqueRandom(CITIES, state.recentCities, CONFIG.limits.maxRecentCities);
        const productIndex = getWeightedProduct();
        const nameIndex = Math.floor(Math.random() * NAMES.length);
        const product = PRODUCTS[productIndex];

        document.getElementById('cvs-customer-name').textContent = NAMES[nameIndex];
        document.getElementById('cvs-city').textContent = CITIES[cityIndex];
        document.getElementById('cvs-product-name').textContent = product.name;
        document.getElementById('cvs-product-img').src = product.image;
        document.getElementById('cvs-value').textContent = product.value;
        document.getElementById('cvs-time').textContent = getTimeAgo();
        document.getElementById('cvs-stock').textContent = product.stock;

        popup.style.display = 'block';
        state.isVisible = true;
        state.popupCount++;

        setTimeout(hidePopup, CONFIG.timing.displayDuration);
    }

    function hidePopup() {
        const popup = document.querySelector('.cvs-social-proof');
        if (!popup) return;

        popup.classList.add('cvs-hiding');
        
        setTimeout(() => {
            popup.style.display = 'none';
            popup.classList.remove('cvs-hiding');
            state.isVisible = false;
        }, 300);
    }

    // Auto-init when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Public API
    window.CVSPopup = {
        show: showPopup,
        hide: hidePopup
    };

})();
