// Local questions and answers
const surveyData = {
    questions: [
        {
            name: "What is your favorite color?",
            answers: ["Red", "Blue", "Green", "Yellow"]
        },
        {
            name: "What is your preferred mode of transportation?",
            answers: ["Car", "Bike", "Bus", "Walking"]
        },
        {
            name: "Which type of movies do you like?",
            answers: ["Action", "Romance", "Comedy", "Horror"]
        },
        {
            name: "What is your favorite cuisine?",
            answers: ["Italian", "Mexican", "Indian", "Chinese"]
        },
        {
            name: "What type of pet do you own?",
            answers: ["Dog", "Cat", "Bird", "Other"]
        },
        {
            name: "How often do you shop online?",
            answers: ["Daily", "Weekly", "Monthly", "Rarely"]
        },
        {
            name: "Which sport do you prefer?",
            answers: ["Soccer", "Basketball", "Tennis", "Cricket"]
        }
    ]
};

let currentStep = 0;

function startSurvey() {
    renderQuestion();
}

function renderQuestion() {
    const totalQuestions = surveyData.questions.length;

    if (currentStep < totalQuestions) {
        const currentQuestion = surveyData.questions[currentStep];
        const progress = ((currentStep + 1) / totalQuestions) * 100;

        // Update question text
        document.getElementById("questionText").innerHTML = `<span style='font-size: 18px'><strong>Question ${currentStep + 1} of ${totalQuestions}:</strong></span><p class='question mt-2'>${currentQuestion.name}</p>`;

        // Update answer choices
        const questionBody = document.getElementById("questionBody");
        questionBody.innerHTML = ""; // Clear existing content
        currentQuestion.answers.forEach(answer => {
            const button = document.createElement("button");
            button.className = "btn-tx-color btn-color survey_button btnh-color btnh-tx-color";
            button.innerText = answer;
            button.onclick = () => nextQuestion();
            questionBody.appendChild(button);
        });

        // Update progress bar
        const progressBar = document.getElementById("progressBar");
        progressBar.style.width = `${progress}%`;
        progressBar.setAttribute("aria-valuenow", progress);
    } else {
        // End of survey
        document.getElementById("questionTemplate").innerHTML = "<h3>Thank you for completing the survey!</h3>";
    }
}

function nextQuestion() {
    currentStep++;
    renderQuestion();
}

// Initialize survey on page load
document.addEventListener("DOMContentLoaded", startSurvey);
