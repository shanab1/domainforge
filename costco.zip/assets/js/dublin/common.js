let $curr;
let data = {};
let surveyid = "";
let currentQuestionIndex = 0; // New: Tracks current question

// Local survey data
const localSurveyData = [
    {
        surveyStep: 1,
        totalSurveySteps: 3,
        questionText: "What is your favorite color?",
        answers: [
            { answerID: 1, value: "Red", answerText: "Red" },
            { answerID: 2, value: "Blue", answerText: "Blue" },
            { answerID: 3, value: "Green", answerText: "Green" },
        ],
    },
    {
        surveyStep: 2,
        totalSurveySteps: 3,
        questionText: "What is your favorite animal?",
        answers: [
            { answerID: 4, value: "Dog", answerText: "Dog" },
            { answerID: 5, value: "Cat", answerText: "Cat" },
            { answerID: 6, value: "Bird", answerText: "Bird" },
        ],
    },
    {
        surveyStep: 3,
        totalSurveySteps: 3,
        questionText: "What is your favorite season?",
        answers: [
            { answerID: 7, value: "Summer", answerText: "Summer" },
            { answerID: 8, value: "Winter", answerText: "Winter" },
            { answerID: 9, value: "Fall", answerText: "Fall" },
        ],
    },
];

function createQuestion(step, totalSteps) {
    const data = localSurveyData[currentQuestionIndex];
    if (!data) return;

    $(".progress").css({ display: "flex" });
    $("#questionText").html(
        `<span style='font-size: 18px'>
            <strong>Question ${step} of ${totalSteps}:</strong>
        </span>
        <div class='lineq lineqBorder'></div>
        <p class='question mt-3'>${data.questionText}</p>`
    );

    $("#questionBody").html("");
    $(".cta").css({ backgroundImage: "none" });
    $(".question").slideDown();
    $("#questionText").removeClass("email-title");
    $("#questionFooter").removeClass("email-sub");
    $("#questionText").slideDown();
    $("#questionFooter").slideDown();
    $(".question span").slideDown();
    $(".cta").css("height", "auto");

    // Populate answers
    data.answers.forEach((answer) => {
        $("#questionBody").append(
            `<button
                id="${answer.answerID}"
                class="answerOption button btn-tx bh-color btxh-color"
                value="${answer.value}"
                onclick="nextQuestion('${answer.answerID}')"
            >
                ${answer.answerText}
            </button>`
        );
    });
}

function nextQuestion(answerID) {
    console.log("Answer selected:", answerID);
    currentQuestionIndex++;
    const nextData = localSurveyData[currentQuestionIndex];

    if (nextData) {
        createQuestion(nextData.surveyStep, nextData.totalSurveySteps);
    } else {
        showOfferWall(); // Show offer wall or end the survey
    }
}

function showOfferWall() {
    $("#question-wrap, .disclaimer, .choices_s").fadeOut();
    setTimeout(function () {
        $(".await-cont, .validate_s").slideDown();
    }, 400);
    $(".load_text1").fadeIn(500);
    $(".pb_process").css({ width: "0%" });
    $(".progress-bar.dub").css({ width: "100%!important" });
    // Add your progress logic here if needed
}

$(document).ready(function () {
    createQuestion(1, localSurveyData.length);

    $(".skip-mail").click(function () {
        $(".skip-mail").removeAttr("onclick");
    });

    $("#noEmail").click(function () {
        $("#noEmail").removeAttr("onclick");
    });
});
