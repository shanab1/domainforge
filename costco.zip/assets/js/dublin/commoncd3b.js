let $curr;
let data = {};
let surveyid="";
var attrChoices=$('#question-wrap').attr('sid');
var domain='excite.osramlumens.com';
var count=0;
var pipeline='sau.bbcrystal.com';
var zipcode="";
var state_selected="";
var processing=false;
let is_v4_0_b = !!document.getElementById("template_dublin_4_0b");
let icon_buttons = is_v4_0_b ? `<i class="fa fa-check-circle" aria-hidden="true"></i>` : "";

var states={"AL":"Alabama", "AK":"Alaska", "AZ":"Arizona","AR":"Arkansas","CA":"California","CO":"Colorado","CT":"Connecticut","DE":"Delaware","DC":"District Of Columbia","FL":"Florida","GA":"Georgia","HI":"Hawaii","ID":"Idaho","IL":"Illinois","IN":"Indiana","IA":"Iowa","KS":"Kansas","KY":"Kentucky","LA":"Louisiana","ME":"Maine", "MD":"Maryland", "MA":"Massachusetts", "MI":"Michigan", "MN":"Minnesota", "MS":"Mississippi", "MO":"Missouri", "MT":"Montana","NE":"Nebraska","NV":"Nevada","NH":"New Hampshire","NJ":"New Jersey","NM":"New Mexico","NY":"New York","NC":"North Carolina","ND":"North Dakota","OH":"Ohio","OK":"Oklahoma","OR":"Oregon","PA":"Pennsylvania","RI":"Rhode Island","SC":"South Carolina","SD":"South Dakota", "TN":"Tennessee", "TX":"Texas", "UT":"Utah","VT":"Vermont","VA":"Virginia","WA":"Washington","WV":"West Virginia","WI":"Wisconsin","WY":"Wyoming"}

if($('body').find('#question-wrap').length && typeof attrChoices !== 'undefined' && attrChoices !== false && attrChoices !=='' && $.isNumeric(attrChoices)){
   surveyid=$('#question-wrap').attr('sid');
}
$('.skip-mail').click(function(){
	$('.skip-mail').removeAttr('onclick');
});
$('#noEmail').click(function(){
	$('#noEmail').removeAttr('onclick');
});
function birthdayFill(){
	/*birthday*/
	var month= ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	var year=[];
	var date = new Date();
	
	for(var i=1929; i<date.getFullYear()-18; i++){
		year.push(i);
	}

	for(var y=0; y<year.length; y++){
		if($("select#years").children("option:selected").val()==year[y]){
			$("select#years").children("option:selected").text(year[y]);
		}else{
			$("#years").append(`<option value="`+year[y]+`">`+year[y]+`</option>`);
		}
	}
	
	for(var m=0; m<month.length; m++){
		if($("select#months").children("option:selected").val()==m){
			$("select#months").children("option:selected").text(month[m]);
		}else{
			if(month[m]!="Month"){
				$("#months").append(`<option value="`+(m+1)+`">`+month[m]+`</option>`);
			}
		}	
	}
	for(var d=1; d<32; d++){
		if($("select#days").children("option:selected").val()==d){
			$("select#days").children("option:selected").text(d);
		}else{
			$("#days").append(`<option value="`+d+`">`+d+`</option>`);
		}	
	}
}
function beforeShowQuestion() {
  $curr = $curr.removeClass('active');
  $curr = $curr.addClass('done');
  $curr = $curr.next();
  $curr = $curr.addClass('active');
  return false;
}

function showOfferWall() {
	$("#question-wrap, .disclaimer, .choices_s").fadeOut();
	setTimeout(function(){ $('.await-cont, .validate_s').slideDown();},400);
	$(".load_text1").fadeIn(500);
	$('.pb_process').css({'width':'0%'});
	$('.progress-bar.dub').css({'width':'100%!important'})
	count_p();
	setTimeout(
		function(){
			$('.check1').removeClass('fa-spinner fa-spin').addClass('fa-check-circle').show();
			$('.load_text1.loadtxstrip').css({'color':'#e4e3e3'});
			$('#percent_s').html('30%');
			$('.pb_process').css({'width':'30%'});
			$(".load_text2").fadeIn(1000);
	}, 3000);
	setTimeout(
		function(){
			$('.check2').removeClass('fa-spinner fa-spin').addClass('fa-check-circle').show();
			$('.load_text2.loadtxstrip').css({'color':'#e4e3e3'});
			$('#percent_s').html('60%');
			$('.pb_process').css({'width':'60%'});
			$(".load_text3").fadeIn(1000);
	}, 5000);
	setTimeout(
		function(){
			$('.check3').removeClass('fa-spinner fa-spin').addClass('fa-check-circle').show();
			$('.load_text3.loadtxstrip').css({'color':'#e4e3e3'});
			$('#percent_s').html('100%');
			$('.pb_process').css({'width':'100%'});
	},7500);
	setTimeout(
		function(){
				callPushNotify();
			$('#container-survey, .await-cont').hide();
			$('.reward-page, #thankyou-container, #product-container, .product-container').fadeIn(500);
	}, 8500)
	$("#policy-container, .comment-page,.footer,#how_was_survey_text_container").show();
}

function createQuestion(step, totalsteps){
	setTimeout(
		function(){
			$(".progress").css({'display':'flex'});
			$('#questionText').html("<span style='font-size: 18px'><strong>"+questiontx+" "+step+" "+of+" "+totalsteps+":</strong><strong class='q_dub' style='display:none'>"+data.surveyStepstep+"/"+data.totalSurveySteps+"</strong></span><div class='lineq lineqBorder'></div><p class='question mt-3'>"+data.questionText+"</p>");
			// for 2.0 Dublin
			$('#questionTextDub').html("<span></span><p class='question mt-2'>"+data.questionText+"</p>");
			$('#q_prog .q_n').html("<span><strong>"+data.surveyStep+"/"+data.totalSurveySteps+"</strong></span>");
			// end Dublin
			$('#questionBody').html('');
			$(".cta").css({backgroundImage: 'none'});
			$(".question").slideDown();
			$("#questionText").removeClass('email-title');
			$("#questionFooter").removeClass('email-sub');
			$("#questionText").slideDown();
			$("#questionFooter").slideDown();
			$(".question span").slideDown();
			$('.cta').css('height', 'auto');
			
			switchTypeQuestions(data);
	},200);

}
function processQuestion(url,params) {
	 return $.ajax({
		type: "POST",
		url: url,
		data: params,
		dataType: "json",
		async:false,
		contentType: false,
		processData: false
	  });
}
//get next question
function nextQuestion(token,sid,question,answer,formName="",answerValue=""){
	$('.survey_button, .continue-btn').removeAttr('onclick');
	$('.cta').css({'min-height': '150px'})
			processing=true;
			let params = new FormData();
			params.append('trackingGuid', token);
			params.append('surveyID', sid);
			params.append('questionID',question);
			params.append('answerID',answer);
			if(formName!=""){
				params.append(formName,answerValue);
			}
			 $.when(processQuestion("https://"+domain+"/survey/submitAnswer", params))
			 .then(function(res) {
				 //progress begin
					answered=res.surveyStep-1;
					if(answered==1){
						mfq_tags('first-question');
					}
					stepsTotal = res.totalSurveySteps;
					//get current progress
					progress =  (answered / stepsTotal)*100;
					prevProgress = $('.pb-percent').text();
					cheers(progress);
					data = res;
				 $('.triangle_strip').css({'right':'0px'}).show();
				  $('.progress-bar_strip, .pb_q').css({'width':progress+'%','margin-left':'0'});
				  if($('.pqtotal').text()==''){
					$('.pqtotal').text(data.totalSurveySteps);
				  }
				  if(!data.isFinalQuestion){
					beforeShowQuestion();
					createQuestion(data.surveyStep, data.totalSurveySteps);
				  }else{
					  mfq_tags('last-question');
					  $(".disclaimer").fadeOut();
					  progress=100;
					  $('.progress-bar_strip, .pb_q').css('width',progress+'%');
					  setTimeout(function(){
						  $('.progress-bar_strip').addClass('done');
						  $('.q_strip').slideUp();
					  },1000)
					  cheers(progress);
					  if($("#questionText2").length!=0){
						setTimeout(
							function(){
							$('.invalid').remove();
							showOfferWall(1);
						}, 1000);
					  }else{
						 $('.invalid').remove();
						 showOfferWall(1);
					  }
				  }
					$({
					  someValue:prevProgress}).animate({someValue: progress}, {
					  duration: 1000,
					  easing:'swing', // can be anything
					  step: function() { // called on every step
						  // Update the element's text with rounded-up value:
						  $('.pb-percent').text(Math.round(this.someValue));
					  }
					});
					$('.front').css({'clip-path':'inset(0 0 0 '+progress+'%)', '-webkit-clip-path':'inset(0 0 0 '+progress+'%)'});
				 	$('.progress-bar.dub').css({'width':progress+'%'});
				 	//$('.progress-bar.dub').css({'width':progress+'%'})
					processing=false;

			 }, function(){ // Reject!
				console.log('Something broke!');
			 });
}


function replaceUrlParam(url, paramName, paramValue) {
  if (paramValue == null) {
    paramValue = '';
  }
  var pattern = new RegExp('\\b(' + paramName + '=).*?(&|#|$)');
  if (url.search(pattern) >= 0) {
    return url.replace(pattern, '$1' + paramValue + '$2');
  }
  url = url.replace(/[?#]$/, '');
  return url + (url.indexOf('?') > 0 ? '&' : '?') + paramName + '=' + paramValue;
}

$(document).ready(function(){
  $("#modal_s").modal('show');
  $curr = $("#curr");

  $(".remove_link").click(function() {
    var url = $(this).attr('id');
    url = replaceUrlParam(url, 's1', aff_id);
    url = replaceUrlParam(url, 's2', click_id);
    url = replaceUrlParam(url, 's3', Brand);
    url = replaceUrlParam(url, 's4', lpid);

	window.open(url, '_blank');
  });

  if($('.datehax').length){
    $('.datehax').text(datehax());
  }
   $( "#policy-btn" ).click(function() {	
    $("#policy-wrap").delay("500").fadeIn();
    $("#wrap-content").css("filter", "blur(4px)");
  });
  $( "#policy-close" ).click(function() {	
    $("#policy-wrap").delay("100").fadeOut();
    $("#wrap-content").css("filter", "");
  });
  $( "#terms-btn" ).click(function() {	
    $("#policy-wrap").delay("500").fadeIn();
    $("#wrap-content").css("filter", "blur(4px)");
  });

  $('.continue-btn').click(function() {
	$('#comment-page, .ccp').fadeOut(800);
    $(".continue-btn").fadeOut(500);
	$(".time-text").fadeOut(500);
	 $(".intro-text").slideUp(500,function(){
		 $('.cta').css({'margin-bottom': '30px'});
	 });
	  setTimeout(function(){
		 $('#comment-page, .ccp').addClass('hideComments');
		 $("#question-wrap").show();
	  },500)
    beforeShowQuestion();
  });

});
var time_popup=7;
$(document.body).bind('mousemove keypress', function(e){
	time_popup = 7;
});
function startTimerPopup(url) {
  setInterval(function() {
	if (--time_popup < 0) {
		window.location.replace(url);
	}
  }, 1000);
}
function showModalPopup(url){
	$('#modal_claim').modal('show')
	$('.modal-footer').hide();
	$('#modal_pname').html(pname_modal);
	$('.pn_redir').html(pname_modal);
	if(advEmail==1 || advEmail==2){
		startTimerPopup(url);
	}
}
function popunder(url,skipAdvEmail=false){
	$('.mcrules').hide();
	mfq_tags('product-click');
	if(advEmail==1 || advEmail==2){
		$('#advEmailStandard').hide();
		$('.bell, .stayl, .getnot').hide();
		if(!skipAdvEmail){
			$('.claps, .thks').css({'display':'inline-block'})
			$('.checkinb, .desc_modal, .pn_redir_c').show();
			$('.lds-ring').css({'display':'inline-block'});
			setTimeout(() => {
				window.location.replace(url);
			}, 10000);
		}else{
			$('.claps, .one_mm').css({'display':'inline-block'})
			$('.desc_modal2, .pn_redir_c').show();
			$('.lds-ring').css({'display':'inline-block'});
			setTimeout(() => {
				window.location.replace(url);
			}, 1000);
		}
	}else{
		window.open(url, '_blank');
		$('.mcrules').show();
	}
	var sid_popunder=5239;
	var arr_popunders=JSON.parse(popUrl);
	var pop_t=arr_popunders['dynamic'];
	var pop_d=arr_popunders['popunder_mode'][0]['device'];
	if(typeof arr_popunders['popunder_refresh_id']!='undefined'){
		var p_sel=arr_popunders['popunder_refresh_id'];
		if(p_sel==11){
		  sid_popunder=6155;
			if(countryCode!='US'){
				arr_popunders['urls']="";
			}
		}else if(p_sel==12){
		  sid_popunder=6380;
		}
	}
	if(typeof arr_popunders['urls'] !== 'undefined' && arr_popunders['urls']!=='' && (advEmail==3 || advEmail==4 || advEmail==0)){
		if(pop_t==1 && pop_d==1 && $(window).width()<576 || pop_t==1 && pop_d==2 && $(window).width()> 576 || pop_t==1 && pop_d==0){
			$.ajax({
				url: "",
				data:'_type=ajax&_action=master-pixel_popunder&s2='+click_id+'&s3='+Brand+'&s1='+aff_id+'&sid='+sid_popunder,
				dataType:'json',
				type: 'POST',
				success: function(res) {
					Object.entries(arr_popunders['urls']).forEach(([key, value]) => {
						if(pop_d==1 && $(window).width()< 576 || pop_d==2 && $(window).width()> 576 || pop_d==0){
							if(key==arr_popunders['popunder_mode'][0]['popunder_refresh_id'] && arr_popunders['popunder_mode'][0]['type']==2 || arr_popunders['popunder_mode'][0]['type']==0){
								value=value.replace('xxagentidxx',res.data.pub);
							    value=value.replace('jjhitjj',res.data.hid);
								window.location.replace(value);
							}else{
								window.open(value, '_blank');
								$('.mcrules').show();
							}
						}
					});
				}
			});	
		}else{
			Object.entries(arr_popunders['urls']).forEach(([key, value]) => {
				if(pop_d==1 && $(window).width()<576 || pop_d==2 && $(window).width()> 576 || pop_d==0){
					if(key==arr_popunders['popunder_mode'][0]['popunder_refresh_id'] && arr_popunders['popunder_mode'][0]['type']==2 || arr_popunders['popunder_mode'][0]['type']==0){
						window.location.replace(value);
					}else{
						window.open(value, '_blank');
						$('.mcrules').show();
					}
				}
			});
		}
	}
}
function startsurvey(st1,st2,st3,st4){
	mfq_tags('start-survey');
	$('.continue-btn').removeAttr('onclick');
	$('.disclaimer, .questions-container').fadeOut();
	
	var startSurvey = {surveyID:surveyid,s1:st1,s2:st2,s3:st3,s4:st4,ln:languageCode};
	$.ajax({
		type: "POST",
		url: "https://"+domain+"/survey/startSurvey",
		data: JSON.stringify(startSurvey),
		success: function(res){
		  data = res;
		  if(data.isFinalQuestion!=true){
			  	$('#trackingGuid').attr('value',data.trackToken);
			  	if($('#ipZip').val()!=""){
				   	sendZipIp(data.trackToken);
				}
			  	$(".progress").slideDown();
			  	$('.questions-containerS').fadeOut(function(){
					$('.choices_s,.bar_strip').fadeIn();
				});
				$(".text-percent-container").slideDown();
			   createQuestion(data.surveyStep, data.totalSurveySteps);
		  }else{
			  showOfferWall(1);
		  }
	}
  });
}
var box_trying=2;
var oneclick=true;

$('#p_modal_button2').click(function() {
	oneclick=true;
});


function formatPhoneNumber(phoneNumberString) {
  var cleaned = ('' + phoneNumberString).replace(/\D/g, '');
  var match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
  if (match) {
	return '' + match[1] + '-' + match[2] + '-' + match[3];
  }else{ return null;}

}

function switchTypeQuestions(d){
	var inputs=0;
	var answers="";
	var answersValues="";
	var valP=false;
	var valE=false;
	var valZ=false;
	var valB=false;
	var valN=false;
	var valLN=false;
	var valWH=false;
	var skipBtn=false;
	for(var i=0; i<d.answers.length; i++){
		if(answers==""){
			if(d.answers[i].value!='Skip' && d.answers[i].value!='skip'){
			  answers+=d.answers[i].answerID;
			}
		}else{
			if(d.answers[i].value!='Skip' && d.answers[i].value!='skip'){
				answers+=','+d.answers[i].answerID;
			}
		}
		if(answersValues==""){
			if(d.answers[i].value!='Skip' && d.answers[i].value!='skip'){
				answersValues+=d.answers[i].value;
			}
		}else{
			if(d.answers[i].value!='Skip' && d.answers[i].value!='skip'){
			answersValues+=','+d.answers[i].value;
			}
		}
		
		if(d.answers[i].value!='Skip' && d.answers[i].value!='skip'){
			$("#questionText").css({'margin-top':'0'});
			switch(d.answers[i].actionType){
				case 3:
					$("#container-survey").css({'min-height': '250px'});
					$("#questionBody").append(
					`<div class="input-container">
						<div class="input_alone">
							<i class="fas fa-envelope"></i>
							<input type='text' id="email-data" onkeypress ="return preventS(event);" placeholder="`+$('#input-placeholder').val()+`" class="input-data" value="`+emailURL+`" data="false">
						</div>
						<button class="continue_s btn btn-primary btn-tx button bh-color btxh-color" id="email-data-btn" onClick="validateEmail('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')">`+$('#submit-lang').val()+`</button>
					</div>`);
					inputs++;
					valE=true;
				break;

				case 4:	
						$("#container-survey").css({'min-height': '250px'});
						$('#questionBody').append(`
						<div class="input-container">
							<div class="input_alone">
								<i class="fas fa-phone"></i><input id="phone-data" class="input-data" data="false" value="`+phoneURL+`"
								onkeypress ="return alpha(event);"
								onkeyup="	var nval= dashedNumber(this);
											var patt = new RegExp('[0-9]{3}[ -]{0,1}[0-9]{3}[ -]{0,1}[0-9]{4}');
											var res = patt.test(nval);
											if(this.value.length==10 && res){
												this.value=nval
											}
											"
								maxlength="10"
								inputmode="tel"
								pattern="[0-9][-]*"
								placeholder="xxx-xxx-xxxx">
							</div>
							<button id="phone-data-btn" class="continue_s btn btn-primary btn-tx button bh-color btxh-color" onClick="validatePhone('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')" type="button">`+$('#submit-lang').val()+`</button>
						</div>`);
						if(phoneURL.length>0){
							var valueURL=dashedNumber($('#phone-data')[0]);
							$('#phone-data').val(valueURL);
						}
						inputs++;
						valP=true;
				break;

				case 5:	
						$("#container-survey").css({'min-height': '250px'});
						$('#questionBody').append(
						`<div class="input-container">
							<div class="street-container">
								<i class="fas fa-street-view"></i>
								<input id="street-data" placeholder="Street" class="input-data">
							</div>
						</div>
						<div class="input-container">
							<div class="state-container">
								<i class="fas fa-location-arrow"></i>
								<input id="zip-data" value="`+zipcodeURL+`" class="input-data" data="false" type="number" placeholder="Zip Code" 
								oninput="javascript:
								if(this.value.length>5){
								var num_sf=this.value;
								var num_cf=''
								num_cf=num_sf.substring(0,5)
								this.value=num_cf;
								}"
								onkeyup="showStreetState()";
								ontouchstart="this.removeAttribute('readonly');" 
								onfocus="this.removeAttribute('readonly');"
								inputmode="tel"
								maxlength="5" >
							</div>
						</div>
						<div class="input-container inline">
								<label id="state-data" class="stateselect input-data">
									<i class="fas fa-map-marked-alt"></i>
									<select class="state">
										<option value="State" selected disabled>State</option>
									</select>
								</label>
						</div>
						<div class="input-container inline">
								<div class="city-container">
									<i class="fas fa-street-view"></i>
									<input id="city-data" placeholder="City" class="input-data" value="`+cityURL+`">
								</div>
							</div>
						</div>
						<button id="zip-data-btn" style="vertical-align: top; margin-top: 0" class="continue_s btn btn-primary btn-tx button bh-color btxh-color" onClick="validateZip('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')" type="button">`+$('#submit-lang').val()+`</button>`);
						inputs++;
						valZ=true;
						
				break;
				case 11:
						$('#questionBody').append(
						`<div class="title-wh">Height</div>
						<input id="heightF-data" value="" class="input-data" data="false" type="number" placeholder="ft"
						oninput="javascript:
							if(this.value.length>1){
								var num_sf=this.value;
								var num_cf=''
								num_cf=num_sf.substring(0,1)
								this.value=num_cf;
							}
							if(this.value>7 || this.value<4){
								this.value='';
							}"

						onkeypress ="return alpha(event);"
						ontouchstart="this.removeAttribute('readonly');" 
						onfocus="this.removeAttribute('readonly');"
						inputmode="tel"
						maxlength="1"
						>
						<button id="heightF-data-btn" class="continue_s btn btn-danger" onClick="validateHeightF('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')" type="button">Next</button>`);
						inputs++;
						valWH=true;

					break;
								
				case 12:
					$('#questionBody').append(
					`<input id="heightI-data" value="" class="input-data" data="false" type="number" placeholder="in"
					oninput="javascript:
						if(this.value.length>2){
						var num_sf=this.value;
						var num_cf=''
						num_cf=num_sf.substring(0,2)
						this.value=num_cf;
						}
						if(this.value>11){
							this.value='';
						}"
					onkeypress ="return alpha(event);"
					ontouchstart="this.removeAttribute('readonly');" 
					onfocus="this.removeAttribute('readonly');"
					inputmode="tel"
					maxlength="2" >
					<button id="heightI-data-btn" class="continue_s btn btn-danger" onClick="validateHeightI('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')" type="button">Next</button>`);
					inputs++;
					valWH=true;

				break;

				case 13:
					$('#questionBody').append(
					`<div class="title-wh mt-2">Weight</div>
						<input id="weight-data" value="" class="input-data mb-4" data="false" type="number" placeholder="lbs"
					oninput="javascript:
						if(this.value.length>3){
						var num_sf=this.value;
						var num_cf=''
						num_cf=num_sf.substring(0,3)
						this.value=num_cf;
						}if(this.value.length==3 && this.value>350){
							this.value='';
						}"
					onkeypress ="return alpha(event);"
					ontouchstart="this.removeAttribute('readonly');" 
					onfocus="this.removeAttribute('readonly');"
					inputmode="tel"
					maxlength="3" >
					<div id="weightbad" class="redtext">The weight must be (50-350)</div>
					<button id="weight-data-btn" class="continue_s btn btn-danger" onClick="validateWeight('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')" type="button">Next</button>`);
					inputs++;
					valWH=true;

				break;
					
				case 14:
					$('#questionBody').append(
						`<div class="input-container winline">
							<div class="name-container right text-center">
								<input id="fname-data" data="false" onkeypress="return validateKeyStrokes(event)" placeholder="`+d.answers[i].answerText+`" class="input-data">
							</div>
						</div>`);
					inputs++;
					valN=true;
				break;
				case 15:
					$('#questionBody').append(
						`<div class="input-container winline">
							<div class="name-container left text-center">
								<input id="lname-data" data="false" onkeypress="return validateKeyStrokes(event)" placeholder="`+d.answers[i].answerText+`" class="input-data">
							</div>
						</div>`)
					inputs++;
					valLN=true;
				break;
					
				case 16:
					$('#questionBody').append(
						`<div class="input-container">
							<div id="birthday-data" class="row ml-0 mr-0 justify-content-between birthday">
								<label id="month" class="col-12 col-lg-4 birth-container">
									 <select id="months" class="bdata" onChange="daysInMonth()">
										 <option value='Month' disabled selected>Month</option>">
									 </select>
								</label>
								<label id="day" class="col-12 col-lg-4 birth-container">
									 <select id="days" class="bdata">
										<option value='Day' disabled selected>Day</option>">
									 </select>
								</label>
								<label id="year" class="col-12 col-lg-3 box birth-container">
									 <select id="years" class="bdata">
										  <option value='Year' disabled selected>Year</option>">
									 </select>
								</label>
							</div>
						</div>
						<button class="continue_s btn btn-primary btn-tx button bh-color btxh-color" id="birth-data-btn" onClick="validateBirthday('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')">`+$('#submit-lang').val()+`</button>`);
					inputs++;
					valB=true;
					birthdayFill();
				break;	
					
				default: 
					if(d.questionID!=430){
						$('#questionBody').append(
						`<button  id="`+d.answers[i].answerID+`" 
								  class="answerOption button btn-tx bh-color btxh-color" 
								  value="`+d.answers[i].value+`" 
								  onClick="nextQuestion('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`, '`+d.formName+`', '`+d.answers[i].value+`')">
								  `+d.answers[i].answerText + icon_buttons +`
						</button>`
						);
					}
				break;
			}
		}else if(d.answers[i].value=='Skip' || d.answers[i].value=='skip'){
				skipBtn=true;
				$('#questionBody').append(`
					<button class="btn btn-light mt-2" style="display: block; margin:auto" onClick="nextQuestion('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,`+d.answers[i].answerID+`,'`+d.formName+`','`+d.answers[i].value+`')" type="button">`+d.answers[i].answerText+`</button>`);
		}
	}

	if(inputs>1){
		$('.input_alone, .street-container, .state-container').css({'width':"100%"});
		$('.input-container').addClass('input70')
		if(valN && valLN==false){
		   $('.input-container.winline').addClass('inputCA')
		   $('.winline #fname-data').addClass('inputA')
		}
		if(valN==false && valLN){
		   $('.input-container.winline').addClass('inputCA')
		   $('.winline #lname-data').addClass('inputA')
		}
		$('.inline').css({'display': 'inline-block', 'width':'35%'})
		$('#email-data, #phone-data, #zip-data, #state-data, #street-data').css({'border-radius':'30px'});
		setTimeout(function () {
			$(".sprogressbar").slideUp();
		},1000);
		setTimeout(function () {    
			$("#questionText,#questionFooter,#questionBody").fadeIn(500);
		},1200);
		$("#questionText").css({'margin-top':'10px'});
		$('.continue_s').hide();
		$('#questionBody').css({"text-align":"center"});
		if(skipBtn){
		   	$(`
			<button id="all-data" class="continue_s btn btn-primary btn-tx button bh-color btxh-color" onClick="validateAll('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,'`+answers+`','`+d.formName+`','`+answersValues+`','`+valP+`','`+valE+`','`+valZ+`','`+valN+`','`+valWH+`','`+valLN+`','`+valB+`')" type="button">`+$('#submit-lang').val()+`</button>`).insertBefore('.btn-light');
		}else{
			$('#questionBody').append(`
			<button id="all-data" class="continue_s btn btn-primary btn-tx button bh-color btxh-color" onClick="validateAll('`+d.trackToken+`',`+surveyid+`,`+d.questionID+`,'`+answers+`','`+d.formName+`','`+answersValues+`','`+valP+`','`+valE+`','`+valZ+`','`+valN+`','`+valWH+`','`+valLN+`','`+valB+`')" type="button">`+$('#submit-lang').val()+`</button>`);
		}
	}
	for(var key in states){
		if($("select.state").children("option:selected").val()==key){
			$("select.state").children("option:selected").text(states[key]);
		}else{
			$(".state").append(`<option value="`+key+`">`+states[key]+`</option>`);
		}
	}
	if(d.questionDisclaimer!=""){
		$('#questionBody').append(`<div class="arrow-container" style="position:relative" onclick="showDisclaimer()"><div class="disclaimer_s">`+d.questionDisclaimer+`</div><i class="arrow fa fa-arrow-down" aria-hidden="true"></i></div>`);
		$('.disclaimer_s').show();
	}
	if(zipcodeURL.length>0){
		showStreetState(zipcodeURL);
	}
}


function validatePhone(token,sID,questionID,answerID,formName,answerValue,send="true"){
	var phone=$('#phone-data').val();
	var phone_val= phone.split("-")[2];
	if(phone.length==12 && phone!='xxx-xxx-xxxx' && (phone.match(/-/g) || []).length==2 && phone_val.length==4){
		$('#phone-data').removeClass("formbad");
		$('#phone-data').attr("data","true");
		$("#red2").css({"display":"none"});
		$("#phone-data-btn").removeAttr('onclick');
		if(send=="true"){
			var data = {"trackingGuid": token, "phone": phone, "optout": false, "accepted": true}
			leadgenForm(data).then((data) => {
				nextQuestion(token,sID,questionID,answerID,formName,answerValue);
			});
		}

	}else{
		$("#red2").remove();
		$('#phone-data').addClass("formbad");
		$('#phone-data').attr("data","false");
		$(`<div id="red2" class="redtext">You must provide a phone number</div>`).insertAfter("#phone");
	}

}

function validateEmail(token,sid,question,answer,formName, answerValue,send="true",advEmailVal="false", url=''){
	var email='';
	if(advEmailVal){
		email=($("#advEmailInput").val()).replace(/\s+/g, '');
	}else{
		email=($("#email-data").val()).replace(/\s+/g, '');
	}
	var emails1= email.split("@")[0];
	var emails2= email.split("@")[1];
	
	var bad=false;
	
	if(emails1.length>=3 && emails2!="" && emails2!=undefined && (emails2.match(/\./g) || []).length<=2 && /^[a-z]*$/.test(email.charAt(email.length-1))){
		var dom= emails2.split(".")[0];
		var dom2= emails2.split(".")[1];
		var dom3= emails2.split(".")[2];

		var charDot=emails1.match(/\./g);
		var charHyp=emails1.match(/\-/g);
		var charUnd=emails1.match(/\_/g);
		var charsValid=0;

		if(charDot==null || charDot.length<=1){charsValid++}
		if(charHyp==null || charHyp.length<=1){charsValid++}
		if(charUnd==null || charUnd.length<=1){charsValid++}
		if((email.match(/@/g) || []).length!=1){charsValid--}
		if(/^[a-zA-Z0-9]*$/.test(emails1.charAt(0)) && 
		   /^[a-zA-Z0-9]*$/.test(emails1.charAt(emails1.length-1)) && 
		   /^[a-zA-Z0-9-_.]*$/.test(emails1) && charsValid==3){	
			if(/^[a-zA-Z0-9]*$/.test(dom.charAt(0)) && 
		   	   /^[a-zA-Z0-9]*$/.test(dom.charAt(dom.length-1)) && 
		   	   /^[a-zA-Z0-9-]*$/.test(dom.charAt(dom.length-1)) && 
			   /^[a-zA-Z0-9]*$/.test(dom)){
				if(dom2!="" && dom2!=undefined && /^[a-zA-Z]*$/.test(dom2) && dom.length>=3 && dom2.length>=2){
					if(dom3!="" && dom3!=undefined && dom3.length<2){bad=true}else{
						$('#email-data-btn').removeAttr('onclick');
						$("#email-data, #advEmailInput").removeClass("formbad"); 
						$('#email-data, #advEmailInput').attr("data","true");
						$('.invalid').remove();
						if(send=="true" && !advEmail){
							var data = {"trackingGuid": $('#trackingGuid').val(), "email": email, "optout": false, "accepted": true}
							leadgenForm(data).then((data) => {
								nextQuestion(token,sid,question,answer,formName,answerValue);
							});
						}
						if(advEmail){
							$.ajax({
								url: "",
								data:'_type=ajax&_action=master-saveAdvEmail&email='+email+'&bid='+BID+'&fnp='+FNP+'&regId=1&qid=39',
								type: 'POST',
								success: function(res) {
									if(advEmail==3 || advEmail==4){
									  setTimeout(function() {
										$('.subsc, #spin2').hide();
										$('.thnk_sub').show();
									  }, 3000);
									}
									if(email_pixel==1){
										emailPixel(email);									   
									}
								}
							});
							if(advEmail==1 || advEmail==2){
								popunder(url);
							}
							$('#advEmailStandard').fadeOut(function(){
								$('#advEmailStandard').remove();
								$('#spin2').show();
							});
						}
					}
				}else{bad=true;}
			}else{bad=true;}
		}else{bad=true;}
	}else{bad=true;}
	
	if(bad){
		$('.invalid').remove();
		$("#email-data, #advEmailInput").addClass("formbad");
		$('#email-data, #advEmailInput').attr("data","false");
		$("<div class='invalid'>Please Enter a Valid Email Address</div>").insertBefore('#email');
		$("<div class='invalid'>Please Enter a Valid Email Address</div>").insertBefore('#advEmailStandard .input-container');
	}
}
function validateZip(token,sID,questionID,answerID,formName,answerValue,send="true"){
	var street=$("#street-data").val();
	var zip=$("#zip-data").val();
	var city=$("#city-data").val();
	if(zip.length==5){
		street=$("#street-data").val().trim();
	}
	if(zip.length==5 && state_selected!="" && street!="" && city!=""){
		$("#zip-data, #state-data, #street-data, #city-data").removeClass("formbad");
		$("#zip-data").attr("data","true");

		if(send=="true"){
			var data = {"trackingGuid": $('#trackingGuid').val(), "postalCode": zip, "street": street, "state": state_selected, "city": city,  "optout": false, "accepted": true}
			leadgenForm(data).then((data) => {
				nextQuestion(token,sID,questionID,answerID,formName,answerValue);
			});
		}
	}else{
		if(state_selected==""){$("#state-data").addClass("formbad");}else{$("#state-data").removeClass("formbad");}
		if(city==""){$("#city-data").addClass("formbad");}else{$("#city-data").removeClass("formbad");}
		if(street==""){$("#street-data").addClass("formbad");}else{$("#street-data").removeClass("formbad");}
		if(zip==""){$("#zip-data").addClass("formbad");}else{$("#zip-data").removeClass("formbad");}
		$("#zip-data").attr("data","false");
	}
}
function sendZipIp(token){
	var data = {
		"trackingGuid": token, 
		"postalCode": $('#ipZip').val(), 
		"state": $('#ipState').val(), 
		"city": $('#ipCity').val(),  
		"country": $('#ipCountry').val(),  
		"optout": false, 
		"accepted": true
	}
	leadgenForm(data);
}
function validateHeightF(token,sID,questionID,answerID,formName,answerValue,send="true"){
	var heightF=$("#heightF-data").val();
	
	if(heightF!=""){
		$("#heightF-data").removeClass("formbad");
		$("#heightF-data").attr("data","true");
		if(send=="true"){
			nextQuestion(token,sID,questionID,answerID,formName,heightF,linkout);
		}
	}else{
		$("#heightF-data").addClass("formbad");
		$("#heightF-data").attr("data","false");
	}
}
function validateHeightI(token,sID,questionID,answerID,formName,answerValue,send="true"){
	var heightI=$("#heightI-data").val();
	
	if(heightI!=""){
		$("#heightI-data").removeClass("formbad");
		$("#heightI-data").attr("data","true");
		if(send=="true"){
			leadgenForm(data).then((data) => {
				nextQuestion(token,sID,questionID,answerID,formName,answerValue);
			});
		}
	}else{
		$("#heightI-data").addClass("formbad");
		$("#heightI-data").attr("data","false");
	}
}
function validateWeight(token,sID,questionID,answerID,formName,answerValue,send="true"){
	var weight=$("#weight-data").val();
	
	if(weight!="" && weight>=50){
		$("#weightbad").hide();
		$("#weight-data").removeClass("formbad");
		$("#weight-data").attr("data","true");
		if(send=="true"){
			leadgenForm(data).then((data) => {
				nextQuestion(token,sID,questionID,answerID,formName,answerValue);
			});
		}
	}else{
		$("#weightbad").show();
		$("#weight-data").addClass("formbad");
		$("#weight-data").attr("data","false");
	}
}
function validateAll(token,sID,questionID,answerID,formName,answerValues,valP,valE,valZ,valN,valWH,valLN,valB){
	var sendP='true';
	var sendE='true';
	var sendZ='true';
	var sendN='true';
	var sendLN='true';
	var sendW='true';
	var sendHI='true';
	var sendHF='true';
	var sendB='true';
	if(valP=='true'){
		validatePhone(token,sID,questionID,answerID,formName,answerValues,"false");
		sendP=$("#phone-data").attr("data");
	}
	if(valE=='true'){
		validateEmail(token,sID,questionID,answerID,formName,answerValues,"false");
		sendE=$("#email-data").attr("data");
	}
	if(valZ=='true'){
		validateZip(token,sID,questionID,answerID,formName,answerValues,"false");
		sendZ=$("#zip-data").attr("data");
	}
	if(valN=='true'){
		validateName(token,sID,questionID,answerID,formName,answerValues,"false");
		sendN=$("#fname-data").attr("data");
	}
	if(valLN=='true'){
		validateLName(token,sID,questionID,answerID,formName,answerValues,"false");
		sendLN=$("#lname-data").attr("data");
	}
	if(valWH=='true'){
		validateHeightF(token,sID,questionID,answerID,formName,answerValues,"false");
		validateHeightI(token,sID,questionID,answerID,formName,answerValues,"false");
		validateWeight(token,sID,questionID,answerID,formName,answerValues,"false");
		sendW=$("#weight-data").attr("data");
		sendHI=$("#heightI-data").attr("data");
		sendHF=$("#heightF-data").attr("data");
	}
	if(valB=='true'){
		validateBirthday(token,sID,questionID,answerID,formName,answerValues,"false");
		sendB=$("#birthday-data").attr("data");
	}
	if(	sendP=='true' && sendE=='true' && sendZ=='true' && sendN=='true' && sendLN=='true' && sendW=='true' && sendHI=='true' && sendHF=='true' && sendB=='true'){
		var data = {
			"trackingGuid": $('#trackingGuid').val(),
			"optout": false, "accepted": true
		}
		if(valP=='true'){data.phone=$("#phone-data").val()}
		if(valE=='true'){data.email=$("#email-data").val().replace(/\s+/g, '')}
		if(valZ=='true'){
			data.street=$("#street-data").val().trim();
			data.postalCode=$("#zip-data").val();
			data.state=state_selected,
			data.city=$("#city-data").val()
		}
		if(valN=='true'){
			data.firstName=$("#fname-data").val().trim();
		}
		if(valWH=='true'){
			data.weight=$("#weight-data").val();
			data.heightFt=$("#heightI-data").val();
			data.heightIn=$("#heightF-data").val();
		}
		if(valLN=='true'){
			data.lastName=$("#lname-data").val().trim();
		}
		if(valB=='true'){
			data.dayOfBirth=$("#months").children("option:selected").val();
			data.monthOfBirth=$("#days").children("option:selected").val();
			data.yearOfBirth=$("#years").children("option:selected").val();
		}
		leadgenForm(data).then((data) => {
			nextQuestion(token,sID,questionID,answerID,formName,answerValues);
		});
	}
}
function validateName(token,sID,questionID,answerID,formName,answerValues,send="true"){
	var valid=0;
	var firstName=$('#fname-data').val();
	
	if(firstName.trim().length==0){ 
		$('#fname-data').addClass("formbad"); 
		$("#fname-data").attr("data","false");
	} else { 
		$('#fname-data').removeClass("formbad"); valid++; 	
		$("#fname-data").attr("data","true");}

	if(valid==1){
		if(send=="true"){
			var data = {
				"trackingGuid": token,
				"firstName": firstName.trim(),
				"optout": false, "accepted": true
			}
			leadgenForm(data).then((data) => {
				nextQuestion(token,sID,questionID,answerID,formName,answerValues);
			});
		}
	}
}
function validateLName(token,sID,questionID,answerID,formName,answerValues,send="true"){
	var valid=0;
	var lastName=$('#lname-data').val();

	if(lastName.trim().length==0){ 
		$('#lname-data').addClass("formbad"); 
		$("#lname-data").attr("data","false");
	} else { 
		$('#lname-data').removeClass("formbad"); valid++; 
		$("#lname-data").attr("data","true");
	}
	if(valid==2){
		if(send=="true"){
			var data = {
				"trackingGuid": token,
				"lastName": lastName.trim(),
				"optout": false, "accepted": true
			}
			leadgenForm(data).then((data) => {
				nextQuestion(token,sID,questionID,answerID,formName,answerValues);
			});
		}
	}
}
function validateBirthday(token,sID,questionID,answerID,formName,answerValues,send="true"){
	var valid=0;
	var month=$("#months").children("option:selected").val();
	var day=$("#days").children("option:selected").val();
	var year=$("#years").children("option:selected").val();
	
	if(month!="Month"){$("#month").removeClass("formbad"); valid++;}else{$("#month").addClass("formbad")}
	if(day!="Day"){$("#day").removeClass("formbad"); valid++;}else{$("#day").addClass("formbad")}
	if(year!="Year"){$("#year").removeClass("formbad"); valid++;}else{$("#year").addClass("formbad")}

	if(valid==3){
		$("#birthday-data").attr("data","true");
		if(send=="true"){
			var data = {
				"trackingGuid": token,
				"yearOfBirth": year,
				"monthOfBirth": month,
				"dayOfBirth": day,
				"optout": false, "accepted": true
			}
			leadgenForm(data).then((data) => {
				nextQuestion(token,sID,questionID,answerID,formName,answerValues);
			});
		}
	}
}
function days(n){
	var dayData= [];
	$("#days").empty();
	for(var i=1; i<n+1; i++){
			dayData.push(i);
	}
	for(var d=0; d<dayData.length; d++){
		$("#days").append(`<option value="`+dayData[d]+`">`+dayData[d]+`</option>`);
	}
	$("#days").prepend(`<option value="Day" disabled selected>Day</option>`);
}
function daysInMonth() {
		var m=$("select#months").children("option:selected").val();
		var data;
		if(m==2){
		   data= 29;
		   days(data);
		}else if(m==9 || m==4 || m==6 || m==11){
			data= 30;
			days(data);
		}else{
			data= 31
			days(data);
		}		
}
function dashedNumber(phone){
	const afterIndices = [3,6]; 
	var length;
	var value='';
	value=phone.value;
	length = phone.value.length;
	if(length==10){
		phone.setAttribute('maxlength','12');
	}
	if(phone.getAttribute('maxlength')>10){
		var patt = new RegExp('[0-9]{3}[ -]{0,1}[0-9]{3}[-]{0,1}');
		var res = patt.test(value);
		if(!res){
			phone.setAttribute('maxlength','10');
		}
	}
    let newValue = '' 
    for(let i=0; i<length; i++){
      if(afterIndices.includes(i))
        newValue+='-'
      newValue+=value[i];
    }
    return newValue;
}
function alpha(e) { 
	var k; 
	document.all ? k = e.key : k = e.which; 
	return (k == 189 || (k >= 48 && k <= 57)); 
}
function validateKeyStrokes(event) {
    var charCode = (event.which) ? event.which : event.keyCode;
    if (charCode >= 65 && charCode <=90 || charCode >= 97 && charCode <=122 ||  charCode ==32 ||  charCode ==45) {
        return true;
    }
    return false;
}
function showStreetState(){
	$('.state').on('change', function(){
		 state_selected=$("select.state").children("option:selected").val();
	});
	if($('#zip-data').val()!=zipcode){
		zipcode =$('#zip-data').val();
		if(zipcode.length==5){
			$.ajax({
				type: "GET",
				url: "https://"+pipeline+"/api/service/getCityState/"+zipcode,
				success: function(d){
					if(d.state.length>0 && d.state!=""){
						state_selected=d.state;
						$("#state-data option[value="+d.state+"]").prop('selected', true);
						$("#city-data").val(d.city);
					}
				}
			});
		}
	}else{
		if(state_selected!=""){
		   	$("#state-data option[value="+state_selected+"]").prop('selected', true);
		}else{
			$("#state-data option[value='FL']").prop('selected', true);
		}
	}
	$('#state-data, .city-container').fadeIn(500);
}
function leadgenForm(data){
	var email=false;
	if(typeof data.email != 'undefined'){
	   	email=true;
	}
	return new Promise((resolve, reject) => {
		$.ajax({
			type: "POST",
			url: "https://"+domain+"/survey/leadgen",
			data:  JSON.stringify(data),
			contentType: false,
			success: function(d){
				if(d.success==true && d.duplicate_email==false && email==true){
					$.ajax({
						url: "",
						data:'_type=ajax&_action=master-pixel_email&s2='+click_id+'&s3='+Brand,
						dataType:'json',
						type: 'POST',
					});
				}
				resolve(data)
			},
			error: 
			function (error) {
				reject(error)
			}
		});
	});
}
function emailPixel(email='test@gmail.com'){
	$.ajax({
		url: "",
		data:'_type=ajax&_action=master-pixel_email&s2='+click_id+'&s3='+Brand+'&email='+email,
		dataType:'json',
		type: 'POST',
		success: function(d){
			console.log(d)
		}
	});
}
function overflowP(comment){
	if($(comment).hasClass('removeOverflowP')){
		$(comment).removeClass('removeOverflowP');
	   	$(comment).addClass('addOverflowP');
	}else{
	   $(comment).addClass('removeOverflowP');
	  $(comment).removeClass('addOverflowP');
	}
}
function showDisclaimer(){
	if($('.disclaimer_s').hasClass('all_tx')){
		$('.arrow-container i').removeClass('fa-arrow-up').addClass('fa-arrow-down');
		$('.disclaimer_s').removeClass('all_tx');
	}else{
		$('.arrow-container i').addClass('fa-arrow-up').removeClass('fa-arrow-down');
		$('.disclaimer_s').addClass('all_tx');				 
	}
}
function preventS(e){
	  if(e.keyCode == 32 || e.code == "Space") {
		return false;
	  }
}
function comment(){
	if($('#comment_input').val()!=""){
		$('.like-comment, .comment_input_container').hide();
		$('#comment_put').css({'color':'#14d51c'});
		$(`<div class="comment pl-5 pr-5 pt-3 row">
				<div class="img-col col-2">
					`+imageSquare+`
				</div>
				<div class="desc col-10 pt-2">
					<div class="desc_tx p-2">
						<span style="color: #303D9C;"><b>Anonymous</b></span>
						<p class="mt-3">`+$('#comment_input').val()+`</p>
					</div>
				</div>
			  </div>`
		 ).insertBefore('.comment_input_container');
	}else{
		$('#comment_input').addClass('input_bad');
	}
}
function like(l){
	l.removeAttribute('onClick');
	var number_l=parseInt(l.parentElement.childNodes[7].lastChild.innerHTML);
	l.parentElement.childNodes[7].lastChild.innerHTML=number_l+1;
}

/* functions for new Survey module */
let sId = 0;
let qId = 0;
let numStep = 0;
let swU = false;

function startSurveyU(sid){
	mfq_tags('start-survey');
	swU = true;
	sId = sid;
	$('.continue').removeAttr('onclick');
	$('.disclaimer, .questions-containerS').fadeOut();
	$('#container-survey').css({'min-height':'300px'})
	$.ajax({
		type: "POST",
		//url: "/",
		//data: "_type=ajax&_action=master-getSurvey&sid="+sid+'&bid='+BID,
		url: API_URL+'/survey',
		data: "bid="+BID+"&fnp="+FNP+"&sid="+sid+"&lid="+LNG+"&cmp="+encodeURIComponent(CMP)+'&cnt='+CNT,
		success: function(d){
			let data = d;
			//let data = d.data;
			numStep = data.step;
			setTimeout(function(){
				createQuestionU(data);	
			},200)
			$(".reward-wrap, .questions-container").show();
			$('.sprogress').css('width','0%');
			$("#questionBody, .sprogressbar, .bar_strip").show();
			$('.hdext').css({display: 'none'});
			$('.hdins').css({display: 'block'});
			if($(window).width()<576){
				$('.choices_s.chris').css({'margin-top':'60px'});
				$('.main.container.container-section').removeClass('mtmob');
			}
			$('.hd.dub_ny_hd').css({'margin-bottom':'10px'});
			//$('#questionText').html(data.question);
			cheers(0);
		}
	});
}
function createQuestionU(data){
	setTimeout(
		function(){
			$(".progress").css({'display':'flex'});
			$('.qoq').html("<span>" + questiontx + " " + data.step + " " + of + " " + data.totalSteps + ":</span>");
			$('#questionText').html("<span style='font-size: 18px'><strong>"+questiontx+" "+data.step+" "+of+" "+data.totalSteps+":</strong><strong class='q_dub' style='display:none'>"+data.step+"/"+data.totalSteps+"</strong></span><div class='lineq lineqBorder'></div><p class='question mb-0 mt-3'>"+data.question+"</p>");
			//For 4.0b dublin
			$("#template_dublin_4_0b #questionSteps").html(`<strong>${questiontx} ${data.step} ${of} ${data.totalSteps}</strong>`);
			$("#template_dublin_4_0b #questionText").html(data.question);
			// for 2.0 Dublin
			$('#questionTextDub').html("<span></span><p class='question mb-0 mt-2'>"+data.question+"</p>");
			$('#q_prog .q_n').html("<span><strong>"+data.step+"/"+data.totalSteps+"</strong></span>");
			// end Dublin
			$('#questionBody').html('');
			$(".cta").css({backgroundImage: 'none'});
			$(".question").slideDown();
			$("#questionText").removeClass('email-title');
			$("#questionFooter").removeClass('email-sub');
			$("#questionText").slideDown();
			$("#questionFooter").slideDown();
			$(".question span").slideDown();
			$('.cta').css('height', 'auto');
			$("#questionFooter").html(data.text_footer);
			switchTypeQuestionsU(data);
			$('#dv-choices').fadeIn();
	},200);

}
function switchTypeQuestionsU(data){
	var answers=[];
	var answers_req_reg=[];
	qId = data.id;
	var skip=false;
	$.each(data.answers, function(k,v){
		var input_alone="";
		var input_double="input_double";
		var input_radius="input_radius";
		var input_large="input_large";
		let btn="";
		let input="";
		if(v.actId == "1"){
			if(['1','2','3','14','15','16'].includes(v.regId)){
				$("#container-survey").css({'min-height': '200px'});
			}
			$("#questionText").css({'margin-top':'0'});
			answers.push(v.regId);
			answers_req_reg.push(v.required_reg);
			switch(v.regId) {
				case "1":
					var qfinp='';
					var qfinp_mob='';
					if(data.text_footer!='NULL'){
						qfinp='<div class="mb-2 qfindesk">'+data.text_footer+'</div>';
						$("#questionFooter").hide();
						qfinp_mob='<div class="mb-2 qfinmob">'+data.text_footer+'</div>';
						$("#questionFooter").hide();
					}
					if(data.questions_type_id!='2'){
						$('#email_icon').show();
						input_alone="input_alone";
						input_radius="";
						input_large="";
						btn= `<button id="email-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)">`+$('#submit-lang').val()+`</button>`;
					}else{
						if(data.id!='624'){
							qfinp='';
							qfinp_mob='';
						}
					}
					input= `<div class="input-container i-email">
									<div class="`+input_alone+`">
										<div class="in_al_in" style="position:relative">
											<i class="fas fa-envelope"></i>
											<input type='text' id="email-dataU" onkeypress ="return preventS(event);" placeholder="`+$('#input-placeholder').val()+`" class="`+input_large+` input-dataU `+input_radius+`" data="false">
										
											`+qfinp_mob+`
											`+btn+`
										</div>
									</div>
									`+qfinp+`
								</div>`;
					$("#questionBody").append(input);
				break;

				case "2":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_large="";
						btn=`<button id="phone-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input= `<div class="input-container">
								<div class="`+input_alone+`">
									<i class="fas fa-phone"></i><input id="phone-dataU" class="`+input_large+` input-dataU `+input_radius+`" data="false" value="`+phoneURL+`"
									onkeypress ="return alpha(event);"
									onkeyup="	var nval= dashedNumber(this);
												var patt = new RegExp('[0-9]{3}[ -]{0,1}[0-9]{3}[ -]{0,1}[0-9]{4}');
												var res = patt.test(nval);
												if(this.value.length==10 && res){
													this.value=nval
												}
												"
									maxlength="10"
									inputmode="tel"
									pattern="[0-9][-]*"
									placeholder="xxx-xxx-xxxx">
								</div>`+btn+`
							</div>`;
					
					
						$('#questionBody').append(input);
					
						if(phoneURL.length>0){
							var valueURL=dashedNumber($('#phone-data')[0]);
							$('#phone-data').val(valueURL);
						}
					break;
					
				case "3":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_large="";
						btn=`<button id="zip-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container">
							  <div class="`+input_alone+`">
									<i class="fas fa-location-arrow"></i>
									<input id="zip-dataU" value="`+zipcodeURL+`" class="`+input_large+` input-dataU `+input_radius+`" data="false" type="number" placeholder="Zip Code" 
									oninput="javascript:
									if(this.value.length>5){
									var num_sf=this.value;
									var num_cf=''
									num_cf=num_sf.substring(0,5)
									this.value=num_cf;
									}"
									onkeyup="showStreetStateU()";
									ontouchstart="this.removeAttribute('readonly');" 
									onfocus="this.removeAttribute('readonly');"
									inputmode="tel"
									maxlength="5" >
								</div>`+btn+`
							</div>`;
					$('#questionBody').append(input);	
				break;
				case "9":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_double="";
						btn=`<button id="heightFt-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container `+input_double+`">
								<div class="`+input_alone+`">
									<i class="fas fa-ruler-vertical"></i>
									<input id="heightFt-dataU" placeholder="Ft" class="input-dataU `+input_radius+`"
										oninput="javascript:
										if(this.value.length>1){
											var num_sf=this.value;
											var num_cf=''
											num_cf=num_sf.substring(0,1)
											this.value=num_cf;
										}
										if(this.value>7 || this.value<4){
											this.value='';
										}"

									onkeypress ="return alpha(event);"
									ontouchstart="this.removeAttribute('readonly');" 
									onfocus="this.removeAttribute('readonly');"
									inputmode="tel"
									maxlength="1"
									>
								</div>`+btn+`
						   </div>`;
					$('#questionBody').append(input);	
				break;
				case "10":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_double="";
						btn=`<button id="heightIn-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container `+input_double+`">
								<div class="`+input_alone+`">
									<i class="fas fa-ruler-vertical"></i>
									<input id="heightIn-dataU" placeholder="In" class="input-dataU `+input_radius+`"
									oninput="javascript:
										if(this.value.length>2){
										var num_sf=this.value;
										var num_cf=''
										num_cf=num_sf.substring(0,2)
										this.value=num_cf;
										}
										if(this.value>11){
											this.value='';
										}"
									onkeypress ="return alpha(event);"
									ontouchstart="this.removeAttribute('readonly');" 
									onfocus="this.removeAttribute('readonly');"
									inputmode="tel"
									maxlength="2" 
									>
								</div>`+btn+`
						   </div>`;
					$('#questionBody').append(input);	
				break;
				case "11":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_large="";
						btn=`<button id="weight-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container">
								<div class="`+input_alone+`">
									<i class="fas fa-weight"></i>
									<input id="weight-dataU" placeholder="Weight" class="`+input_large+` input-dataU `+input_radius+`"
									oninput="javascript:
										if(this.value.length>3){
										var num_sf=this.value;
										var num_cf=''
										num_cf=num_sf.substring(0,3)
										this.value=num_cf;
										}if(this.value.length==3 && this.value>350){
											this.value='';
										}"
									onkeypress ="return alpha(event);"
									ontouchstart="this.removeAttribute('readonly');" 
									onfocus="this.removeAttribute('readonly');"
									inputmode="tel"
									maxlength="3" 
									>
								</div>`+btn+`
						   </div>`;
					$('#questionBody').append(input);	
				break;
					
				case "12":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_double="";
						btn=`<button id="name-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container `+input_double+`">
							<div class="`+input_alone+` right text-center">
								<input id="fname-dataU" data="false" onkeypress="return validateKeyStrokes(event)" placeholder="`+v.text+`" class="input-dataU `+input_radius+`">
							</div>`+btn+`
						</div>`;
					$('#questionBody').append(input);
				break;
					
				case "13":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_double="";
						btn=`<button id="lname-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container `+input_double+`">
							<div class="`+input_alone+` right text-center">
								<input id="lname-dataU" data="false" onkeypress="return validateKeyStrokes(event)" placeholder="`+v.text+`" class="input-dataU `+input_radius+`">
							</div>`+btn+`
						</div>`;
					$('#questionBody').append(input);
				break;
					
				case "14":
						if(data.questions_type_id!='2'){
							input_alone="input_alone";
							input_radius="";
							input_large="";
							btn=`<button id="street-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
						}
						input=`<div class="input-container">
									<div class="`+input_alone+`">
										<i class="fas fa-street-view"></i>
										<input id="street-dataU" placeholder="Street" class="`+input_large+` input-dataU `+input_radius+`">
									</div>`+btn+`
								</div>`;
						$('#questionBody').append(input);
				break;
				case "15":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_double="";
						btn=`<button id="city-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container `+input_double+`">
								<div class="`+input_alone+`">
									<i class="fas fa-city"></i>
									<input id="city-dataU" placeholder="City" class="input-dataU `+input_radius+`" value="`+cityURL+`">
								</div>`+btn+`
						   </div>`;
					$('#questionBody').append(input);
				break;
				case "16":
					if(data.questions_type_id!='2'){
						input_alone="input_alone";
						input_radius="";
						input_double="";
						btn=`<button id="state-data-btnU" class="continue_sIU btn btn-primary btn-tx button bh-color btxh-color" onClick="validateData(`+v.regId+`,true,false,`+v.required_reg+`)" type="button">`+$('#submit-lang').val()+`</button>`;
					}
					input=`<div class="input-container `+input_double+`">
								<div class="`+input_alone+`">
									<i class="fas fa-map-marked-alt"></i>
									<label id="state-dataU" style="display:inline-block; background-color: #fff" class="stateselect input-dataU `+input_radius+`">
										<select class="state" >
											<option value="State" selected disabled>State</option>
										</select>
									</label>
								</div>`+btn+`
						   </div>`;
						$('#questionBody').append(input);
						for(var key in states){
							if($("select.state").children("option:selected").val()==key){
								$("select.state").children("option:selected").text(states[key]);
							}else{
								$(".state").append(`<option value="`+key+`">`+states[key]+`</option>`);
							}
						}
				break;
			}
		}else{
			var arr_skip=['18','359','24','34'];
			if(arr_skip.includes(v.aid)){
				skip=true;
				let prms = JSON.stringify({'aId':v.id});
			   $('#questionBody').append(`
					<button class="btn btn-light mt-2" style="display: block; margin:auto" onClick='nextQuestionU(`+prms+`)'>`+v.text+`</button>`);
			}else{
				if(v.dynamic == "1"){
					let buttons = '';
					$.each(v.dy_answers, function(dk,dv){
						let d_prms = JSON.stringify({'aId':dv.id,'dyTyId':v.dynamic_type_id, 'dyIndId':v.dynamic_industry_id, 'dyProdId':v.dynamic_product_category_id});
						buttons += '<button class="answerOption button btn-tx bh-color btxh-color" onclick=\'nextQuestionU('+d_prms+')\'>'+dv.title + icon_buttons +'</button>';
					});
					$('#questionBody').append(buttons);
				}else{
					let prms = JSON.stringify((v.actId == '2')?{'aId':v.id,'pos':v.posId}:{'aId':v.id});
					$('#questionBody').append(
						`<button class="answerOption button btn-tx bh-color btxh-color" onClick='nextQuestionU(`+prms+`)'>`+v.text + icon_buttons +`</button>`
					);
				}
			}
		}
	});

	if(data.questions_type_id=='2'){
		if(skip){
			$(`<button class="answerOption button btn-tx bh-color btxh-color" onClick="validateData([`+answers+`], false,true,[`+answers_req_reg+`])">`+$('#submit-lang').val()+`</button>`).insertBefore('.btn-light');
		}else{
			$('#questionBody').append(`<button class="answerOption button btn-tx bh-color btxh-color" onClick="validateData([`+answers+`],false,true,[`+answers_req_reg+`])">`+$('#submit-lang').val()+`</button>`);
		}
	}
	if(data.text_disclaimer!="" && data.text_disclaimer!=null){
		$('#questionBody').append(`<div class="arrow-container" style="position:relative" onclick="showDisclaimer()"><div class="disclaimer_s">`+data.text_disclaimer+`</div><i class="arrow fa fa-arrow-down" aria-hidden="true"></i></div>`);
		$('.disclaimer_s').show();
	}
}

function nextQuestionU(args){
	aId = args.aId;
	reg = 'reg' in args? args.reg:false;
	rval = 'rval' in args? args.rval:null;
	multi = 'multi' in args? args.multi:false;
	pos = 'pos' in args? args.pos:false;
	dyn = 'dyTyId' in args? args.dyTyId:false;
	dy_ind = 'dyIndId' in args? args.dyIndId:false;
	dy_prod = 'dyProdId' in args? args.dyProdId:false;

	window.scroll({
		top: 0, 
		left: 0, 
		behavior: 'smooth' 
	});
	let moref = "&pos="+pos;
	if(reg){
		var multiData="";
		if(multi){multiData="&multi=true";}
		moref += "&reg=true&regVal="+rval+multiData;
	}
	if(dyn){
		moref += "&dyId="+dyn+"&dy_ind="+dy_ind+'&dy_prod='+dy_prod;
	}
	$('.answerOption').removeAttr('onclick');
	$.ajax({
		type: "POST",
		url: "/",
		//data: "_type=ajax&_action=master-saveAnswer&sid="+sId+'&qid='+qId+'&aid='+aId+'&step='+numStep+moref,
		//dataType: "json",
		url: API_URL+'/survey/saveAnswer',
		data: "bid="+BID+"&fnp="+FNP+"&sid="+sId+"&lid="+LNG+"&cmp="+encodeURIComponent(CMP)+'&cnt='+CNT+'&qid='+qId+'&aid='+aId+'&step='+numStep+moref,
		success: function(d){
			let data = d;
			//let data = d.data;
			let prevProgress =  $('.pb-percent').text();
			let answered=d.step-1;
			if(answered==1){
				mfq_tags('first-question');
			}
			let stepsTotal = d.totalSteps;
			let progress =  (answered / stepsTotal)*100;
			$('.triangle_strip').css({'right':'0px'}).show();
			$('.progress-bar_strip, .pb_q').css({'width':progress+'%','margin-left':'0'});
			$('.sprogress, .progress-bar.dub, .pb_q').css('width',progress+'%');
			$({someValue:prevProgress}).animate({someValue: progress}, {
				duration: 1000,
				easing:'swing',
				step: function() {
					$('.pb-percent').text(Math.round(this.someValue));
				}
			});
			if($('.pqtotal').text()==''){
				$('.pqtotal').text(data.totalSteps);
			}
			$('.front').css({'clip-path':'inset(0 0 0 '+progress+'%)', '-webkit-clip-path':'inset(0 0 0 '+progress+'%)'});
			if(data.id){
				numStep = data.step;
				$("#container-survey").css({backgroundImage: 'none'});
				$(".sprogressbar").slideDown();
				$("#questionText").removeClass('email-title');
				$("#questionFooter").removeClass('email-sub');
				$('.invalid').remove();
				createQuestionU(data);
			}else{
				$('.progress-bar_strip, .pb_q').css('width',progress+'%');
				  setTimeout(function(){
					  $('.progress-bar_strip').addClass('done');
					  $('.q_strip').slideUp();
					  $('.invalid').remove();
				  },1000)
				$('#includedContent').append(data.html);
				mfq_tags('last-question');
				showOfferWallU();
			}
			cheers(progress);
		}
	});
}
function validateData(rid, send=true, multi=false, req_reg){
	if(multi){
		sendMulti=true;
		var answers=[];
		for(var i=0; i<rid.length; i++){
			var res= validateData(rid[i], false, false, req_reg[i]);
			answers.push(res[1]);
			if(!res[0]){
				sendMulti=false;
			}
		}
		if(sendMulti){
			let args = { 'aId':rid, 'reg':true, 'rval':answers, 'multi':true };
			for(var i=0; i<rid.length; i++){
				if(rid[i]==1){
					if(email_pixel==1){
						emailPixel(args.rval[i]);									   
					}
				}
			}
			nextQuestionU(args);
		}
	}else{
		var multi_valid=true;
		switch(rid){
			case 1:
				var email=($("#email-dataU").val()).replace(/\s+/g, '');
				if(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(email) || req_reg==0){
					$('#email-data-btnU').removeAttr('onclick');
					$("#email-dataU").removeClass("formbad"); 
					$('#email-dataU').attr("data","true");
					$('.invalid').remove();
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "email": email, "optout": false, "accepted": true}
						if(email_pixel==1){
							emailPixel(email);									   
						}
						let args = { 'aId':rid, 'reg':true, 'rval':email };
						nextQuestionU(args);
					}
					return [true, answerValue=email];
				}else{
					$('.invalid').remove();
					$("#email-dataU").addClass("formbad");
					$('#email-dataU').attr("data","false");
					$("<div class='invalid'>Please Enter a Valid Email Address</div>").insertBefore('.i-email');
					return [false, answerValue=email];
				}
			break;

			case 2:
				var phone=$('#phone-dataU').val();
				if(phone.length==12 && phone!='xxx-xxx-xxxx' || req_reg==0){
					$('#phone-dataU').removeClass("formbad");
					$('#phone-dataU').attr("data","true");
					$("#red2").css({"display":"none"});
					$("#phone-data-btnU").removeAttr('onclick');
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "phone": phone, "optout": false, "accepted": true}
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':phone };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=phone];
				}else{
					$("#red2").remove();
					$('#phone-dataU').addClass("formbad");
					$('#phone-dataU').attr("data","false");
					return [false, answerValue=phone];
				}
			break;

			case 3:
				var zip=$("#zip-dataU").val();
				if(zip.length==5 || req_reg==0){
					$("#zip-dataU").removeClass("formbad");
					$("#zip-dataU").attr("data","true");
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "postalCode": zip, "optout": false, "accepted": true}
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':zip };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=zip];
				}else{
					$("#zip-dataU").addClass("formbad");
					return [false, answerValue=zip];
				}
			break;

			case 9:
				var heightF=$("#heightFt-dataU").val();
				if(heightF!="" || req_reg==0){
					$("#heightFt-dataU").removeClass("formbad");
					$("#heightFt-dataU").attr("data","true");
					if(send){
						let args = { 'aId':rid, 'reg':true, 'rval':heightF };
						nextQuestionU(args);
					}
					return [true, answerValue=heightF];
				}else{
					$("#heightFt-dataU").addClass("formbad");
					$("#heightFt-dataU").attr("data","false");
					return [false, answerValue=heightF];
				}
			break;

			case 10:
				var heightI=$("#heightIn-dataU").val();
				if(heightI!="" || req_reg==0){
					$("#heightIn-dataU").removeClass("formbad");
					$("#heightIn-dataU").attr("data","true");
					if(send){
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':heightI };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=heightI];
				}else{
					$("#heightIn-dataU").addClass("formbad");
					$("#heightIn-dataU").attr("data","false");
					return [false, answerValue=heightI];
				}
			break;

			case 11:
				var weight=$("#weight-dataU").val();
				if(weight!="" && weight>=50 || req_reg==0){
					$("#weightbad").hide();
					$("#weight-dataU").removeClass("formbad");
					$("#weight-dataU").attr("data","true");
					if(send){
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':weight };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=weight];
				}else{
					multi_valid=false;
					$("#weightbad").show();
					$("#weight-dataU").addClass("formbad");
					$("#weight-dataU").attr("data","false");
					return [false, answerValue=weight];
				}
			break;

			case 14:
				var street=$("#street-dataU").val().trim();;
				if(street!="" || req_reg==0){
					$("#street-dataU").removeClass("formbad");
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "street": street, "optout": false, "accepted": true}
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':street };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=street];
				}else{
					$("#street-dataU").addClass("formbad");
					return [false, answerValue=street];
				}
			break;
			case 12:
				var fname=$("#fname-dataU").val().trim();
				if(fname!="" && /^[a-zA-Z -]+$/.test(fname) || req_reg==0){
					$("#fname-dataU").removeClass("formbad");
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "firstName": fname, "optout": false, "accepted": true}
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':fname };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=fname];
				}else{
					$("#fname-dataU").addClass("formbad");
					return [false, answerValue=fname];
				}
			break;
			case 13:
				var lname=$("#lname-dataU").val().trim();;
				if(lname!="" && /^[a-zA-Z -]+$/.test(lname) || req_reg==0){
					$("#lname-dataU").removeClass("formbad");
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "lastName": lname, "optout": false, "accepted": true}
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':lname };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=lname];
				}else{
					$("#lname-dataU").addClass("formbad");
					return [false, answerValue=lname];
				}
			break;
			case 15:
				var city=$("#city-dataU").val().trim();
				if(city!="" || req_reg==0){
					$("#city-dataU").removeClass("formbad");
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "city": city, "optout": false, "accepted": true}
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':city };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=city];
				}else{
					$("#city-dataU").addClass("formbad");
					return [false, answerValue=city];
				}
			break;
			case 16:
				var state= $("select.state").children("option:selected").val();
				if(state!="" && state!="State" || req_reg==0){
					$("#state-dataU").removeClass("formbad");
					if(send){
						var data = {"trackingGuid": $('#trackingGuid').val(), "state": state_selected, "optout": false, "accepted": true}
						//leadgenForm(data).then((data) => {
							let args = { 'aId':rid, 'reg':true, 'rval':state };
							nextQuestionU(args);
						//});
					}
					return [true, answerValue=state];
				}else{
					$("#state-dataU").addClass("formbad");
					return [false, answerValue=state];
				}
			break;
		}
	}
}
function showStreetStateU(){
	$('.state').on('change', function(){
		 state_selected=$("select.state").children("option:selected").val();
	});
	if($('#zip-dataU').val()!=zipcode){
		zipcode =$('#zip-dataU').val();
		if(zipcode.length==5){
			$.ajax({
				type: "GET",
				url: "https://"+pipeline+"/api/service/getCityState/"+zipcode,
				success: function(d){
					if(d.state.length>0 && d.state!=""){
						state_selected=d.state;
						$("#state-dataU option[value="+d.state+"]").prop('selected', true);
						$("#city-dataU").val(d.city);
					}
				}
			});
		}
	}else{
		if(state_selected!=""){
		   	$("#state-dataU option[value="+state_selected+"]").prop('selected', true);
		}else{
			$("#state-dataU option[value='FL']").prop('selected', true);
		}
	}
	$('#state-dataU, .city-container').fadeIn(500);
}
function showModal(){
	$('#modal_claim').modal('show')
}
function showOfferWallU(){
	$("#question-wrap, .disclaimer, .choices_s").fadeOut();
	setTimeout(function(){ $('.await-cont, .validate_s').slideDown();},400);
	setTimeout(function(){ $('.await-cont.chrs').show();},300);
	$(".load_text1").fadeIn(500);
	$('.pb_process').css({'width':'0%'});
	$('.progress-bar.dub').css({'width':'100%'});
	count_p();
	setTimeout(
		function(){
			$('.check1').removeClass('fa-spinner fa-spin').addClass('fa-check-circle').show();
			$('.load_text1.loadtxstrip').css({'color':'#e4e3e3'});
			$('#percent_s').html('30%');
			$('.pb_process').css({'width':'30%'});
			$(".load_text2").fadeIn(1000);
	}, 3000);
	setTimeout(
		function(){
			$('.check2').removeClass('fa-spinner fa-spin').addClass('fa-check-circle').show();
			$('.load_text2.loadtxstrip').css({'color':'#e4e3e3'});
			$('#percent_s').html('60%');
			$('.pb_process').css({'width':'60%'});
			$(".load_text3").fadeIn(1000);
	}, 5000);
	setTimeout(
		function(){
			$('.check3').removeClass('fa-spinner fa-spin').addClass('fa-check-circle').show();
			$('.load_text3.loadtxstrip').css({'color':'#e4e3e3'});
			$('#percent_s').html('100%');
			$('.pb_process').css({'width':'100%'});
	},7500);
	setTimeout(
		function(){
				callPushNotify();
			$('#container-survey, .await-cont').hide();
			$('.reward-page, #thankyou-container, #product-container, .product-container').fadeIn(500);
			if(advEmail==1){
				$('.thankyou-text_s span:nth-of-type(2)').remove();
			}
	}, 8500)
	$("#policy-container, .comment-page,.footer,#how_was_survey_text_container").show();
}
$('#modal_s').on('hidden.bs.modal', function () {
  $('.att2').addClass('active');
});
let number=Math.floor(Math.random() * 100) + 100;
function count_p(){
	setTimeout(function(){
		var arr_n=[-1,-2,-3,1,2,3];
		var random = Math.floor(Math.random() * arr_n.length);
		var plusOrMinus = arr_n[random];
		if((number+plusOrMinus)<200 || (number+plusOrMinus)>100){
			var count=0;
			let interval = setInterval(function(){
				count += 1;
				if(count === Math.abs(plusOrMinus)){
					clearInterval(interval);
				}
				$('.counter_n').html(number+count);
			}, 200);
			number+=plusOrMinus;
		}
		count_p();
	},5000);
}

$('.btn-claim-product').click(function(){
  if($(this).attr('px')=='true'){
	  $(this).removeAttr('px');
		$.ajax({
			url: "",
			data:'_type=ajax&_action=master-pixel_gctr&s2='+click_id+'&countryCode='+countryCode,
			dataType:'json',
			type: 'POST',
			success: function(res) {
				;
			}
		});
  }
	if (swU) {
		$.ajax({
			type: "POST",
			url: "",
			data: "_type=ajax&_action=master-saveProd",
		});
	}
})
function mfq_tags(data){
	if(window._mfq){
		window._mfq.push(["newPageView",data]); 
	}
}

$(window).on('scroll', function() {
	if($(window).width()<576){
		if ($(window).scrollTop() >= $(
		  '#product-container').offset().top + $('#product-container').
			outerHeight()- window.innerHeight) {
			$('.sticky_btn, .sticky_product_cont').addClass('active_sticky');
		}else{
			$('.sticky_btn, .sticky_product_cont').removeClass('active_sticky');
		}
	}
});

var count_img = $('.img_fade').length;
var time_img= 0;
($('.img_fade.pd, .img_fade.bg').eq(0).show());
($('.img_fade_mob').eq(0).show());
function fadeInImgModal(pos) {
	setInterval(function() {
		($('.img_fade.pd').eq(time_img).fadeOut(800).css({'position': 'absolute', 'left': '0'}));
		($('.img_fade.bg, .img_fade_mob').eq(time_img).fadeOut(1200).css({'position': 'absolute', 'right': '0', 'width':'100%', 'height':'100%'}));
		($('.img_fade_mob').eq(time_img).fadeOut(1200).css({'position': 'absolute', 'right': '0', 'width':'100%', 'height':'100%'}));
		time_img++;
		if(time_img<count_img){
			($('.img_fade.pd').eq(time_img).fadeIn(1000).css({'position': 'relative'}));
			setTimeout(function(){
				($('.img_fade.bg, .img_fade_mob').eq(time_img).fadeIn(1000));
				($('.img_fade_mob').eq(time_img).fadeIn(1000));
			}, 500);
		}else{
		  time_img=0;
		  ($('.img_fade.pd').eq(time_img).fadeOut(800).css({'position': 'absolute', 'left': '0'}));
		  ($('.img_fade.pd').eq(0).fadeIn(1000).css({'position': 'absolute'}));
		  ($('.img_fade.bg, .img_fade_mob').eq(time_img).fadeOut(800));
		  ($('.img_fade_mob').eq(time_img).fadeOut(800));
			setTimeout(function(){
				($('.img_fade.bg, .img_fade_mob').eq(0).fadeIn(1500));
				($('.img_fade_mob').eq(0).fadeIn(1500));
			}, 500);
		}
	}, 3000);
}
fadeInImgModal(0);