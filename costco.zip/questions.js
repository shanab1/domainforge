const questions = [
  {
    question: "What is your favorite color?",
    choices: ["Red", "Blue", "Green", "Yellow"],
  },
  {
    question: "What is your preferred mode of transportation?",
    choices: ["Car", "Bike", "Bus", "Walking"],
  },
  {
    question: "Which type of movies do you like?",
    choices: ["Action", "Romance", "Comedy", "Horror"],
  },
  {
    question: "What is your favorite cuisine?",
    choices: ["Italian", "Mexican", "Indian", "Chinese"],
  },
  {
    question: "What type of pet do you own?",
    choices: ["Dog", "Cat", "Bird", "Other"],
  },
  {
    question: "How often do you shop online?",
    choices: ["Daily", "Weekly", "Monthly", "Rarely"],
  },
  {
    question: "Which sport do you prefer?",
    choices: ["Soccer", "Basketball", "Tennis", "Cricket"],
  },
];

let currentQuestionIndex = 0;

function loadQuestion() {
  const questionText = document.getElementById("questionText");
  const questionBody = document.getElementById("questionBody");
  const progressBar = document.getElementById("progressBar");

  const question = questions[currentQuestionIndex];

  // Update question text
  questionText.innerHTML = `<h5>Question ${currentQuestionIndex + 1}: ${question.question}</h5>`;

  // Populate answer choices
  questionBody.innerHTML = question.choices
    .map(
      (choice, index) => `
      <div>
        <input type="radio" id="choice${index}" name="question${currentQuestionIndex}" value="${choice}">
        <label for="choice${index}">${choice}</label>
      </div>
    `
    )
    .join("");

  // Update progress bar
  const progressPercentage = ((currentQuestionIndex + 1) / questions.length) * 100;
  progressBar.style.width = `${progressPercentage}%`;
  progressBar.setAttribute("aria-valuenow", progressPercentage);
}

function nextQuestion() {
  const selectedOption = document.querySelector(
    `input[name="question${currentQuestionIndex}"]:checked`
  );

  if (!selectedOption) {
    alert("Please select an answer before proceeding.");
    return;
  }

  // Move to the next question
  currentQuestionIndex++;

  if (currentQuestionIndex < questions.length) {
    loadQuestion();
  } else {
    // Survey completed
    const questionTemplate = document.getElementById("questionTemplate");
    questionTemplate.innerHTML = "<h3>Thank you for completing the survey!</h3>";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  // Load the first question
  loadQuestion();

  // Add event listener to the next button
  document.getElementById("nextButton").addEventListener("click", nextQuestion);
});
